"""Apply the UI layer to generated tool documents; no network or API changes."""
from pathlib import Path
import json,re,html
ROOT=Path(__file__).resolve().parents[1]
TOOLS=json.loads((ROOT/'extension/tools.json').read_text())
E=html.escape
local={'xml-sitemap-generator','keyword-density-checker','hreflang-generator','open-graph-preview','search-intent-classifier','keyword-clustering','seo-content-brief','long-tail-keyword-generator','schema-validator'}
header='''<header class="site-header"><a class="brand" href="/" aria-label="Rank With Ajay home"><span class="brand-mark" aria-hidden="true">↗</span><span>Rank With Ajay<span class="brand-caption">SEO tools &amp; resources</span></span></a><nav aria-label="Main navigation"><a href="/">Home</a><a class="active" aria-current="page" href="/tools/">SEO Tools</a><a href="/about-ajay/">About Ajay</a></nav><a class="header-action" href="/tools/website-seo-audit/">Audit a page <span aria-hidden="true">↗</span></a></header>'''
def apply():
 for path in (ROOT/'tools').rglob('index.html'):
  s=path.read_text()
  if 'design-v2.css' in s:continue
  s=s.replace('</head>','<link rel="stylesheet" href="/extension/design-v2.css"><script defer src="/extension/design-v2.js"></script></head>')
  s=re.sub(r'<header class="site-header">.*?</header>',header,s,flags=re.S)
  slug=re.search(r'data-tool="([^"]+)"',s)[1]
  if slug=='hub':
   s=s.replace('<span class="eyebrow">Practical tools. Everyday SEO.</span>','<span class="eyebrow">THE SEO TOOLKIT</span>')
   s=s.replace('<h1>SEO Tools</h1>','<h1>A clearer path to<br><span>better SEO.</span></h1>')
   s=s.replace('26 focused tools for better websites. Choose a task and get to work.','Check a page, shape your content, or fix the technical details. Find the right tool for the next step.')
   s=s.replace('<section class="filters">','<div class="hub-toolbar"><section class="filters">')
   s=s.replace('placeholder="Search tools…"','placeholder="Try “sitemap”, “keywords” or “meta”…"')
   s=s.replace('<p id="count" role="status">26 tools</p>','<p id="count" role="status">26 tools</p></div><div class="category-shortcuts" aria-label="Filter tools by category"><button type="button" data-category-filter="All categories" aria-pressed="true">All tools <span>26</span></button><button type="button" data-category-filter="On-Page SEO" aria-pressed="false">On-page SEO <span>11</span></button><button type="button" data-category-filter="Technical SEO" aria-pressed="false">Technical SEO <span>10</span></button><button type="button" data-category-filter="Keyword &amp; Content SEO" aria-pressed="false">Keyword &amp; content <span>5</span></button></div>')
   summaries={'On-Page SEO':'Make every page easier to understand.','Technical SEO':'Check the details that keep your website accessible.','Keyword &amp; Content SEO':'Turn topics into focused content.'}
   for title,desc in summaries.items():
    s=s.replace(f'<section class="tool-group"><h2>{title}</h2>',f'<section class="tool-group"><div class="group-heading"><h2>{title}</h2><p>{desc}</p></div>')
  else:
   t=next(t for t in TOOLS if t['slug']==slug)
   s=s.replace('<section class="education">','<section class="education" id="guide">').replace('<h2>Frequently asked questions</h2>','<h2 id="faq">Frequently asked questions</h2>').replace('<section class="related">','<section class="related" id="related">')
   s=s.replace('<section class="workspace"', '<div class="work-layout"><section id="workspace" class="workspace"')
   note='Processed in your browser' if slug in local else 'One page at a time'
   s=s.replace('<div id="tool-input"></div>',f'<div class="workspace-heading"><div><span class="eyebrow">WORKSPACE</span><h2>{"Create & explore" if slug in local else "Check your page"}</h2></div><span class="mode-note">{note}</span></div><div id="tool-input"></div>')
   s=s.replace('<section id="result" hidden aria-label="Results"></section></section>', '<div id="result-placeholder"><span class="placeholder-symbol" aria-hidden="true">↳</span><div><strong>Your results will appear here</strong><p>Complete the fields above, then run the tool.</p></div></div><section id="result" hidden aria-label="Results" tabindex="-1"></section></section>')
   related=[x for x in TOOLS if x['slug'] in t['related']][:3]
   aside=f'<aside class="tool-aside" aria-label="Tool guidance"><div class="aside-section"><span class="eyebrow">QUICK START</span><h2>A little guidance</h2><p>{E(t["how"])}</p></div><div class="aside-section"><h3>Keep in mind</h3><p>{E(t["best"])}</p></div><nav class="page-nav" aria-label="On this page"><a href="#workspace">Use the tool <span>↑</span></a><a href="#guide">How it works <span>↓</span></a><a href="#faq">Common questions <span>↓</span></a></nav><div class="aside-section aside-related"><h3>Continue your workflow</h3>'+''.join(f'<a href="{x["url"]}">{E(x["name"])}<span aria-hidden="true">↗</span></a>' for x in related)+'</div></aside></div>'
   s=s.replace('<noscript>',aside+'<noscript>',1)
  s=s.replace('<footer><strong>Rank With Ajay</strong>', '<footer><div class="footer-brand"><span class="brand-mark" aria-hidden="true">↗</span><strong>Rank With Ajay</strong></div>')
  path.write_text(s)
 p=ROOT/'index.html';s=p.read_text()
 if 'design-v2.css' not in s:s=s.replace('</head>','<link rel="stylesheet" href="/extension/design-v2.css"><script defer src="/extension/design-v2.js"></script></head>')
 p.write_text(s)
if __name__=='__main__':apply()
