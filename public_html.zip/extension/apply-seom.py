from pathlib import Path
r=Path(__file__).resolve().parents[1]
for p in [r/'index.html',*(r/'tools').rglob('index.html')]:
 if p.parent.name=='core-web-vitals':continue
 s=p.read_text()
 if 'seom-theme.css' not in s:p.write_text(s.replace('</head>','<link rel="stylesheet" href="/extension/seom-theme.css?v=20260915-seom"></head>'))
