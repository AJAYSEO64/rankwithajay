'use strict';
(() => {
 const slug=document.body.dataset.tool;
 if(!slug)return;
 const search=document.getElementById('search'), category=document.getElementById('category');
 if(slug==='hub'&&category){
  const buttons=[...document.querySelectorAll('[data-category-filter]')];
  const sync=()=>buttons.forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.categoryFilter===category.value)));
  buttons.forEach(b=>b.addEventListener('click',()=>{category.value=b.dataset.categoryFilter;category.dispatchEvent(new Event('change',{bubbles:true}));sync()}));
  category.addEventListener('change',sync);
  if(search)search.addEventListener('keydown',e=>{if(e.key==='Escape'){search.value='';search.dispatchEvent(new Event('input',{bubbles:true}))}});
  return;
 }
 const form=document.getElementById('form'), feedback=document.getElementById('feedback'), result=document.getElementById('result'), run=document.getElementById('run');
 if(!form||!feedback||!result)return;
 const notice=form.querySelector('.notice');
 if(notice){
  if(['redirect-checker','http-status-checker','broken-link-checker'].includes(slug))notice.textContent='Enter a complete website address beginning with https://. The check runs on the submitted page.';
  else if(slug==='core-web-vitals')notice.textContent='Check real-user loading, responsiveness and visual stability. Some URLs do not have enough field data for a report.';
  else if(form.querySelector('#html'))notice.textContent='Enter a page URL to analyze it, or paste its HTML source for a local check.';
 }
 const decorate=()=>{
  result.querySelectorAll('td').forEach(td=>{
   if(td.dataset.badged)return;
   const value=td.textContent.trim();let type='';
   if(/^(Good|Passed|Working|Present|Self-referencing)(?:\b|$)/i.test(value))type='good';
   else if(/^(Warning|Review|Needs improvement|Redirect|Points elsewhere)/i.test(value))type='warn';
   else if(/^(Issue|Poor|Broken|Missing|Invalid|Blocked)(?:\b|$)/i.test(value))type='issue';
   else if(/^(Unavailable|Not checked|Unable to check|No field data)$/.test(value))type='neutral';
   if(!type||value.length>95)return;
   td.dataset.badged='true';const span=document.createElement('span');span.className='result-badge '+type;span.textContent=value;td.replaceChildren(span);
  });
 };
 new MutationObserver(decorate).observe(result,{childList:true,subtree:true});
 if(run)new MutationObserver(()=>{feedback.setAttribute('aria-busy',String(run.disabled));form.setAttribute('aria-busy',String(run.disabled))}).observe(run,{attributes:true,attributeFilter:['disabled']});
 // Reflect successful copy feedback on the exact button the visitor clicked.
 let copyButton=null,restoreTimer;
 result.addEventListener('click',e=>{const b=e.target.closest('button');if(b&&(/copy/i.test(b.textContent)||b.id==='copy'))copyButton=b});
 new MutationObserver(()=>{if(feedback.textContent==='Copied.'&&copyButton&&copyButton.isConnected){clearTimeout(restoreTimer);const b=copyButton,original=b.dataset.copyLabel||b.textContent;b.dataset.copyLabel=original;b.textContent='Copied ✓';restoreTimer=setTimeout(()=>{if(b.isConnected)b.textContent=original},1800)}}).observe(feedback,{childList:true,subtree:true});
})();
