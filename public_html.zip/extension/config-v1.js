// Same-origin PHP service. No external API key is required.
window.RWA_SEO_API = '/api/seo.php';
