"""Prepare the 28-tool Hostinger release after page generation."""
from pathlib import Path
import re,json,collections,html
ROOT=Path(__file__).resolve().parents[1]
removed='core-web-vitals'
registry=ROOT/'extension/tools.json'
items=[t for t in json.loads(registry.read_text()) if t['slug']!=removed]
for t in items:t['related']=[s for s in t['related'] if s!=removed]
registry.write_text(json.dumps(items,indent=2))
local={'serp-preview','meta-title-generator','meta-description-generator','slug-generator','robots-txt-generator','schema-generator','xml-sitemap-generator','keyword-density-checker','hreflang-generator','open-graph-preview','search-intent-classifier','keyword-clustering','seo-content-brief','long-tail-keyword-generator','schema-validator','canonical-url-generator','open-graph-generator','meta-robots-generator'}
live={'redirect-checker','broken-link-checker','http-status-checker'}
ns='<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WXWMZZC4" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>'
for path in [ROOT/'index.html',*(ROOT/'tools').rglob('index.html')]:
 if path.parent.name==removed:continue
 s=path.read_text()
 s=re.sub(r'<a\b[^>]*href="/tools/core-web-vitals/"[^>]*>.*?</a>','',s,flags=re.S)
 s=s.replace('29 tools','28 tools').replace('29 practical','28 practical').replace('29 Practical','28 Practical')
 if 'ns.html?id=GTM-WXWMZZC4' not in s:s=re.sub(r'(<body\b[^>]*>)',lambda m:m[0]+ns,s,count=1)
 # Version shared assets to avoid stale host/browser caches after upload.
 s=re.sub(r'(/extension/[^"?]+\.(?:js|css))(?:\?v=[^" ]+)?"',r'\1?v=20260911-launch"',s)
 if path==ROOT/'tools/index.html':
  def badge(m):
   card=m[0];slug=re.search(r'href="/tools/([^/]+)/"',card)[1]
   label='Browser tool' if slug in local else 'Live check' if slug in live else 'HTML or live URL'
   card=re.sub(r'<span class="tool-mode[^\"]*">.*?</span>','',card)
   return card.replace('<span class="card-action">',f'<span class="tool-mode">{label}</span><span class="card-action">')
  s=re.sub(r'<a class="tool-card".*?</a>',badge,s,flags=re.S)
  cats=collections.Counter(html.unescape(c) for c in re.findall(r'<a class="tool-card"[^>]*data-category="([^"]+)"',s))
  def counts(m):
   cat=html.unescape(m[1]);n=28 if cat=='All categories' else cats[cat]
   return m[0][:m[0].rfind('<span>')]+f'<span>{n}</span></button>'
  s=re.sub(r'<button[^>]*data-category-filter="([^"]+)"[^>]*>.*?<span>\d+</span></button>',counts,s)
 path.write_text(s)
sitemap=ROOT/'sitemap.xml'
sitemap.write_text(re.sub(r'<url>\s*<loc>https://rankwithajay.in/tools/core-web-vitals/</loc>.*?</url>\s*','',sitemap.read_text(),flags=re.S))
p=ROOT/'extension/legacy-bridge-v1.js'
p.write_text(p.read_text().replace("'core-web-vitals',",'').replace('29 practical','28 practical').replace('29 tools','28 tools'))
# Replace the previously uploaded page, so extraction removes its functionality too.
p=ROOT/'tools/core-web-vitals';p.mkdir(exist_ok=True)
(p/'index.html').write_text('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="robots" content="noindex"><meta http-equiv="refresh" content="0;url=/tools/"><title>SEO Tools | Rank With Ajay</title></head><body><p>This tool has been removed. <a href="/tools/">Browse all 28 SEO tools</a>.</p><script>location.replace("/tools/")</script></body></html>')
(p/'.htaccess').write_text('RewriteEngine On\nRewriteRule ^ /tools/ [R=301,L]\n')
print('Prepared 28 tools, GTM snippets, category counts and retired-route redirect.')
