# MASTER PROMPT — RANK WITH AJAY SEO TOOLS PLATFORM

You are working inside an EXISTING Rank With Ajay website project.

The website is:

[**https://rankwithajay.in/**](https://rankwithajay.in/)

The goal is to expand the existing website into a comprehensive, fast, practical SEO tools platform.

## CRITICAL RULE

DO NOT rebuild the existing project.

DO NOT replace the existing design system.

DO NOT delete existing pages.

DO NOT break existing functionality.

The following pages already exist and must continue working:

- `/`
- `/tools/`
- `/tools/serp-preview/`
- `/tools/meta-title-generator/`
- `/tools/meta-description-generator/`
- `/tools/slug-generator/`
- `/tools/robots-txt-generator/`
- `/tools/schema-generator/`
- `/about-ajay/`

If any of these pages already exist in the project, preserve their functionality and improve only where necessary for consistency.

Before making changes, inspect the existing project architecture, routing, components, styles, SEO implementation and tool structure.

Reuse existing components wherever possible.

---

# PRIMARY OBJECTIVE

Build the next **20 SEO tools** for Rank With Ajay.

The new tools are:

1. Meta Tag Analyzer
2. XML Sitemap Generator
3. SEO Score Checker
4. Redirect Checker
5. Broken Link Checker
6. Keyword Density Checker
7. Heading Checker
8. Canonical URL Checker
9. Hreflang Generator
10. HTTP Status Code Checker
11. Image Alt Text Checker
12. Open Graph Preview
13. Search Intent Classifier
14. Keyword Clustering Tool
15. Internal Link Checker
16. SEO Content Brief Generator
17. Long-Tail Keyword Generator
18. Schema Markup Validator
19. Core Web Vitals Checker
20. Website SEO Audit Tool

Build them under:

`/tools/`

---

# IMPORTANT DEVELOPMENT STRATEGY

Do NOT create 20 completely independent implementations.

First create or improve a reusable SEO tool architecture.

Reuse components such as:

- ToolPageLayout
- ToolHero
- ToolCard
- InputField
- TextareaField
- SelectField
- URLInput
- ResultCard
- StatusBadge
- CharacterCounter
- PixelWidthIndicator
- CopyButton
- DownloadButton
- ClearButton
- LoadingState
- ErrorState
- EmptyState
- FAQ
- RelatedTools
- ToolCTA

If equivalent components already exist, reuse them rather than creating duplicates.

---

# TOOL DATA ARCHITECTURE

Maintain a centralized tool configuration/data structure where practical.

Each tool should have:

- name
- slug
- URL
- category
- description
- icon
- SEO title
- SEO description
- related tools

This will make the Tools Hub easier to maintain.

---

# TOOL CATEGORIES

Organize the Tools Hub into:

## On-Page SEO

- Meta Tag Analyzer
- Keyword Density Checker
- Heading Checker
- Canonical URL Checker
- Image Alt Text Checker
- Open Graph Preview
- SEO Score Checker

## Technical SEO

- XML Sitemap Generator
- Redirect Checker
- Broken Link Checker
- HTTP Status Code Checker
- Hreflang Generator
- Schema Markup Validator
- Core Web Vitals Checker
- Website SEO Audit Tool

## Keyword & Content SEO

- Search Intent Classifier
- Keyword Clustering Tool
- SEO Content Brief Generator
- Long-Tail Keyword Generator
- Internal Link Checker

---

# GLOBAL SEO REQUIREMENTS

Every tool page must have:

- Unique SEO title
- Unique meta description
- Canonical URL
- Open Graph title
- Open Graph description
- Open Graph URL
- One H1
- Logical H2/H3 structure
- Breadcrumb navigation
- BreadcrumbList structured data
- Indexable page
- Internal links to related tools
- FAQ section where appropriate

Do not keyword stuff.

Do not make unsupported SEO claims.

Do not use phrases such as:

"Guaranteed #1 rankings"

"Guaranteed Google ranking"

"100% accurate Google preview"

"Guaranteed rich results"

---

# GLOBAL DESIGN REQUIREMENTS

All tools must visually belong to Rank With Ajay.

Use the existing design system.

Design should be:

- Modern
- Professional
- Clean
- Fast
- Minimal
- Practical
- SEO/SaaS inspired

Use:

- Clear typography
- Rounded cards
- Subtle borders
- Professional accent color
- Good whitespace
- Strong hierarchy

Avoid:

- Excessive gradients
- Excessive animations
- Stock photos
- Generic AI graphics
- Unnecessary decorative elements
- Huge dashboards
- Clutter

The tool itself should be the main visual element.

---

# GLOBAL RESPONSIVE REQUIREMENTS

Every tool must work on:

- Desktop
- Laptop
- Tablet
- Mobile

Mobile requirements:

- Single-column forms
- Full-width controls
- Touch-friendly buttons
- No page-level horizontal scrolling
- Output/code panels may horizontally scroll when technically necessary
- Readable typography
- Accessible controls

---

# GLOBAL ACCESSIBILITY

Use:

- Semantic HTML
- Proper labels
- Keyboard navigation
- Visible focus states
- Accessible buttons
- Accessible accordions
- Helpful validation messages
- Good contrast
- Do not rely only on color for status

---

# GLOBAL SECURITY

Treat all user input as untrusted.

Never execute user-provided HTML, CSS or JavaScript.

Escape/sanitize user values before rendering.

Validate URLs.

Handle failed network requests gracefully.

Never expose API keys in frontend code.

---

# GLOBAL PERFORMANCE

Prioritize:

- Fast initial load
- Minimal JavaScript
- Lazy loading where appropriate
- No unnecessary external libraries
- No unnecessary API requests
- Client-side processing where possible
- Good Core Web Vitals

Do not add an API dependency to tools that can work entirely in the browser.

---

# IMPORTANT BACKEND RULE

Some URL-analysis tools require server-side fetching because browsers cannot safely fetch arbitrary websites due to CORS/security restrictions.

For these tools:

- Meta Tag Analyzer
- Redirect Checker
- Broken Link Checker
- HTTP Status Code Checker
- Image Alt Text Checker
- Internal Link Checker
- Core Web Vitals Checker
- Website SEO Audit Tool

DO NOT fake results.

If the current Hostinger environment supports server-side/API functions, implement them safely.

If the environment does not support the required functionality, create the correct UI architecture and clearly indicate what backend/API capability is required.

Never return fake HTTP status codes, fake SEO scores or fabricated website analysis.

---

# TOOL 1 — META TAG ANALYZER

URL:

`/tools/meta-tag-analyzer/`

H1:

**Meta Tag Analyzer**

Purpose:

Allow a user to enter a URL and analyze important on-page metadata.

Inputs:

**Website URL**

Button:

**Analyze Page**

Analyze where technically possible:

- HTML title
- Meta description
- Canonical URL
- Robots meta
- H1
- H2 headings
- Open Graph title
- Open Graph description
- Open Graph image
- Twitter/X card metadata
- Language
- Viewport
- Favicon

Results should be organized into:

### Basic SEO

- Title
- Description
- Canonical
- Robots

### Headings

- H1 count
- H1 text
- H2 count

### Social

- OG title
- OG description
- OG image
- Twitter/X card

### Technical

- Viewport
- Language
- Favicon

Provide status:

- Passed
- Warning
- Issue

Do not claim that a status automatically determines ranking.

Add:

**Copy Report**

where practical.

SEO title:

**Meta Tag Analyzer – Check SEO Meta Tags | Rank With Ajay**

Meta description:

**Analyze a webpage's title, meta description, canonical, headings, Open Graph tags and other important SEO elements with this free Meta Tag Analyzer.**

---

# TOOL 2 — XML SITEMAP GENERATOR

URL:

`/tools/xml-sitemap-generator/`

H1:

**XML Sitemap Generator**

Allow users to enter multiple URLs.

Features:

- Add URL
- Remove URL
- Change frequency
- Priority
- Last modified date
- Generate sitemap
- Copy sitemap
- Download `sitemap.xml`

Generate valid XML.

Escape XML special characters.

Do not include invalid URLs.

Explain that XML sitemaps help search engines discover URLs but do not guarantee indexing or ranking.

SEO title:

**XML Sitemap Generator – Create a Sitemap | Rank With Ajay**

---

# TOOL 3 — SEO SCORE CHECKER

URL:

`/tools/seo-score-checker/`

H1:

**SEO Score Checker**

Allow URL input.

Analyze only data that can actually be retrieved.

Create categories:

- Title
- Meta description
- Headings
- Canonical
- Robots
- Images
- Links
- Structured data
- HTTPS
- Mobile viewport

Generate a score based on transparent rules.

Display:

**SEO Score: XX/100**

Break down each category.

Do NOT imply that the score is a Google ranking score.

Include:

**This score is a technical checklist based on the checks available to this tool. It is not a Google ranking score.**

If page fetching is unavailable, clearly explain the limitation.

SEO title:

**SEO Score Checker – Analyze Your Website SEO | Rank With Ajay**

---

# TOOL 4 — REDIRECT CHECKER

URL:

`/tools/redirect-checker/`

H1:

**Redirect Checker**

Allow users to enter a URL.

Where server-side HTTP requests are available, follow the redirect chain.

Display:

- Original URL
- Status code
- Redirect destination
- Number of redirects
- Final URL
- HTTP status at each step

Example:

```text
301
https://example.com/old-page/

↓

301
https://www.example.com/old-page/

↓

200
https://www.example.com/new-page/

```

Clearly distinguish:

- 301
- 302
- 307
- 308
- 200
- 404
- 410
- Other statuses

Do not fake results.

SEO title:

**Redirect Checker – Check HTTP Redirects | Rank With Ajay**

---

# TOOL 5 — BROKEN LINK CHECKER

URL:

`/tools/broken-link-checker/`

H1:

**Broken Link Checker**

Allow users to enter a webpage URL.

Where server-side crawling is supported:

- Fetch page
- Extract links
- Check HTTP response
- Identify broken links

Display:

- URL
- Status code
- Link type
- Anchor text
- Status

Categories:

- Working
- Redirect
- Broken
- Blocked
- Unable to check

Allow:

**Export CSV**

Do not crawl unlimited pages.

For V1, analyze the submitted page only.

Add an optional limit such as 100 links.

SEO title:

**Broken Link Checker – Find Broken Links | Rank With Ajay**

---

# TOOL 6 — KEYWORD DENSITY CHECKER

URL:

`/tools/keyword-density-checker/`

H1:

**Keyword Density Checker**

Inputs:

- Text/content
- Optional target keyword

Analyze:

- Word count
- Keyword occurrences
- Keyword density
- Top repeated terms
- 1-word phrases
- 2-word phrases
- 3-word phrases

Do not recommend an arbitrary "ideal keyword density."

Explain:

**There is no universal keyword-density percentage that guarantees rankings. Use the report to identify excessive repetition and understand how frequently terms appear.**

Provide:

- Copy report
- Clear

SEO title:

**Keyword Density Checker – Analyze Keyword Usage | Rank With Ajay**

---

# TOOL 7 — HEADING CHECKER

URL:

`/tools/heading-checker/`

H1:

**Heading Checker**

Allow URL input where fetching is available.

Analyze:

- H1 count
- H1 text
- H2 count
- H3 count
- H4 count
- H5 count
- H6 count

Display heading hierarchy visually:

```text
H1
 ├── H2
 │    ├── H3
 │    └── H3
 └── H2

```

Flag obvious structural issues such as:

- Missing H1
- Multiple H1s
- Empty headings
- Suspicious heading nesting

Do not claim heading hierarchy directly determines rankings.

SEO title:

**Heading Checker – Check H1 to H6 Structure | Rank With Ajay**

---

# TOOL 8 — CANONICAL URL CHECKER

URL:

`/tools/canonical-checker/`

H1:

**Canonical URL Checker**

Input:

URL

Analyze:

- Canonical tag
- Canonical URL
- Self-referencing canonical
- HTTPS
- Host consistency
- Redirect relationship where available

Display:

**Canonical found**

**Canonical URL**

**Status**

Examples:

- Self-referencing
- Points elsewhere
- Missing
- Invalid
- Multiple canonicals

Explain that canonicalization is a signal and does not guarantee which URL Google selects.

SEO title:

**Canonical URL Checker – Check Canonical Tags | Rank With Ajay**

---

# TOOL 9 — HREFLANG GENERATOR

URL:

`/tools/hreflang-generator/`

H1:

**Hreflang Generator**

Allow users to add:

- URL
- Language
- Country code

Example:

```text
English — en
English India — en-IN
English US — en-US
French — fr

```

Generate:

```html
<link rel="alternate" hreflang="en" href="..." />

```

Also support:

`x-default`

Features:

- Add language
- Remove language
- Generate tags
- Copy tags
- Download

Validate language/region format where possible.

SEO title:

**Hreflang Generator – Create Hreflang Tags | Rank With Ajay**

---

# TOOL 10 — HTTP STATUS CODE CHECKER

URL:

`/tools/http-status-checker/`

H1:

**HTTP Status Code Checker**

Input:

URL

Where server-side requests are available, return actual HTTP response information.

Display:

- Status code
- Status message
- Final URL
- Redirect count
- Response time where available
- Content type where available

Explain common codes:

200
301
302
307
308
404
410
500
503

Do not fake results.

SEO title:

**HTTP Status Code Checker – Check Website Response Codes | Rank With Ajay**

---

# TOOL 11 — IMAGE ALT TEXT CHECKER

URL:

`/tools/image-alt-checker/`

H1:

**Image Alt Text Checker**

Input:

URL

Where page crawling is supported:

Extract images.

Display:

- Image URL
- Alt text
- Alt text status
- Width/height if available
- Lazy loading attribute if available

Flag:

- Missing alt
- Empty alt
- Very long alt
- Possible decorative image

Do not claim every image requires descriptive alt text. Explain that decorative images can appropriately use empty alt text.

SEO title:

**Image Alt Text Checker – Check Image SEO | Rank With Ajay**

---

# TOOL 12 — OPEN GRAPH PREVIEW

URL:

`/tools/open-graph-preview/`

H1:

**Open Graph Preview Tool**

Allow manual inputs:

- Page title
- Description
- URL
- Image URL
- Site name

Create realistic previews for:

- Facebook
- LinkedIn
- Generic social share

Where possible, also provide:

**Analyze URL**

to retrieve OG tags.

Add:

Desktop preview

Mobile preview where appropriate.

Show:

- og\:title
- og\:description
- og\:image
- og\:url

Copy metadata option.

SEO title:

**Open Graph Preview Tool – Preview Social Shares | Rank With Ajay**

---

# TOOL 13 — SEARCH INTENT CLASSIFIER

URL:

`/tools/search-intent-classifier/`

H1:

**Search Intent Classifier**

Input:

Keyword or search query.

Classify into:

- Informational
- Navigational
- Commercial
- Transactional
- Local

Provide:

**Primary intent**

**Confidence**

**Why this intent fits**

Also provide:

**Suggested content type**

Examples:

- Blog guide
- Product page
- Service page
- Category page
- Location page
- Comparison page

Do not claim the classification is always correct.

Use rule-based classification for V1.

If AI is available, architecture should allow future AI integration without requiring it now.

SEO title:

**Search Intent Classifier – Identify Keyword Intent | Rank With Ajay**

---

# TOOL 14 — KEYWORD CLUSTERING TOOL

URL:

`/tools/keyword-clustering/`

H1:

**Keyword Clustering Tool**

Allow users to paste keywords, one per line.

Example:

```text
seo tools
free seo tools
best seo tools
seo tools online
free seo checker
seo checker tool

```

Cluster semantically similar keywords using a deterministic method suitable for browser processing.

Display:

Cluster 1

- seo tools
- free seo tools
- best seo tools
- seo tools online

Cluster 2

- seo checker
- seo checker tool
- free seo checker

Allow:

- Add keywords
- Remove keywords
- Generate clusters
- Copy clusters
- Download CSV/TXT

Do not claim perfect semantic understanding.

Clearly label V1 as an approximate clustering tool.

SEO title:

**Keyword Clustering Tool – Group Keywords by Topic | Rank With Ajay**

---

# TOOL 15 — INTERNAL LINK CHECKER

URL:

`/tools/internal-link-checker/`

H1:

**Internal Link Checker**

Input:

URL

Where crawling is supported:

Analyze the submitted page.

Identify:

- Internal links
- External links
- Anchor text
- Target URL
- HTTP status
- NoFollow
- Number of internal links

Highlight:

- Broken internal links
- Empty anchors
- Repeated anchors
- Redirecting internal links

For V1 analyze one submitted page only.

Do not silently crawl an entire website.

SEO title:

**Internal Link Checker – Analyze Internal Links | Rank With Ajay**

---

# TOOL 16 — SEO CONTENT BRIEF GENERATOR

URL:

`/tools/seo-content-brief/`

H1:

**SEO Content Brief Generator**

Inputs:

- Primary keyword
- Secondary keywords
- Search intent
- Audience
- Country/market
- Page type
- Brand

Generate a structured content brief:

- Suggested title
- Search intent
- Target audience
- Primary keyword
- Secondary keywords
- Suggested H1
- Suggested H2s
- Suggested H3s
- Questions to answer
- Internal linking ideas
- Content notes
- CTA suggestion

Do not generate fake keyword search volume or keyword difficulty.

Do not claim the outline guarantees rankings.

Use deterministic templates for V1.

SEO title:

**SEO Content Brief Generator – Create SEO Content Outlines | Rank With Ajay**

---

# TOOL 17 — LONG-TAIL KEYWORD GENERATOR

URL:

`/tools/long-tail-keyword-generator/`

H1:

**Long-Tail Keyword Generator**

Inputs:

- Seed keyword
- Audience
- Location
- Intent

Generate variations using patterns:

- How to...
- Best...
- For beginners
- Near me
- In [location]
- Cost
- Price
- Comparison
- Alternatives
- Review
- Guide
- Checklist
- Examples
- vs
- Services

Allow:

- Copy all
- Copy individual keyword
- Download CSV
- Clear

IMPORTANT:

Do not fabricate search volume, CPC or keyword difficulty.

SEO title:

**Long-Tail Keyword Generator – Find Keyword Ideas | Rank With Ajay**

---

# TOOL 18 — SCHEMA MARKUP VALIDATOR

URL:

`/tools/schema-validator/`

H1:

**Schema Markup Validator**

Allow users to paste:

- JSON-LD
- Schema markup

Validate:

- JSON syntax
- `@context`
- `@type`
- Basic schema structure
- Missing obvious required/important fields where known

Show:

**Valid**

or

**Issues Found**

Display exact errors where possible.

Do not claim that local validation guarantees Google rich-result eligibility.

Provide:

**Format JSON**

**Copy**

**Clear**

SEO title:

**Schema Markup Validator – Validate JSON-LD | Rank With Ajay**

---

# TOOL 19 — CORE WEB VITALS CHECKER

URL:

`/tools/core-web-vitals/`

H1:

**Core Web Vitals Checker**

Allow URL input.

Where an appropriate performance API/service is available, retrieve actual performance information.

Display:

- LCP
- INP
- CLS

Also show:

- Good
- Needs Improvement
- Poor

Explain:

**Core Web Vitals are user-experience performance metrics. They are one part of Google's broader page experience and ranking systems.**

Do not fake measurements.

If a real measurement cannot be performed, explain exactly why.

Do not display invented scores.

SEO title:

**Core Web Vitals Checker – Check LCP, INP & CLS | Rank With Ajay**

---

# TOOL 20 — WEBSITE SEO AUDIT TOOL

URL:

`/tools/website-seo-audit/`

H1:

**Website SEO Audit Tool**

This is the largest tool and should reuse the other analysis components.

Input:

Website URL

For V1, analyze the submitted URL only rather than crawling an entire domain.

Check where technically possible:

### Technical SEO

- HTTPS
- HTTP status
- Canonical
- Robots meta
- Robots.txt
- Sitemap reference

### On-Page SEO

- Title
- Meta description
- H1
- H2
- Images
- Alt text
- Internal links
- External links

### Social

- Open Graph
- Twitter/X metadata

### Structured Data

- JSON-LD
- Schema types

### Performance

- Core Web Vitals where actual data is available

Generate a transparent score.

Example:

```text
OVERALL SEO CHECK
78 / 100

Technical SEO
18 / 20

On-Page SEO
22 / 30

Content Structure
15 / 20

Social Metadata
8 / 10

Structured Data
8 / 10

Performance
7 / 10

```

Every score must be based on actual checks.

Clicking a category should show the individual checks.

Example:

```text
Title
✓ Found
✓ Reasonable length
✓ Contains meaningful page topic

Meta Description
✓ Found
⚠ Could be improved

Canonical
✓ Found
✓ Self-referencing

H1
⚠ Multiple H1 elements found

```

Provide recommendations.

Do not call this a "Google SEO score."

Call it:

**Rank With Ajay SEO Audit Score**

Add disclaimer:

**This audit is a technical checklist and diagnostic aid. It is not a Google ranking score and cannot predict search rankings.**

Do not fabricate data if the URL cannot be fetched.

SEO title:

**Website SEO Audit Tool – Free SEO Checker | Rank With Ajay**

Meta description:

**Run a practical SEO audit of your webpage and check titles, descriptions, headings, links, canonical tags, structured data and technical SEO issues.**

---

# TOOLS HUB UPDATE

Update:

`/tools/`

to include all 26 tools.

Current tools:

1. SERP Preview
2. Meta Title Generator
3. Meta Description Generator
4. Slug Generator
5. Robots.txt Generator
6. Schema Markup Generator

New tools:

7. Meta Tag Analyzer
8. XML Sitemap Generator
9. SEO Score Checker
10. Redirect Checker
11. Broken Link Checker
12. Keyword Density Checker
13. Heading Checker
14. Canonical URL Checker
15. Hreflang Generator
16. HTTP Status Code Checker
17. Image Alt Text Checker
18. Open Graph Preview
19. Search Intent Classifier
20. Keyword Clustering Tool
21. Internal Link Checker
22. SEO Content Brief Generator
23. Long-Tail Keyword Generator
24. Schema Markup Validator
25. Core Web Vitals Checker
26. Website SEO Audit Tool

Organize the Tools Hub by category.

Add search/filter functionality if the existing Tools page architecture supports it without making the page slower.

---

# RELATED TOOLS

Every tool should show 3–5 contextually relevant related tools.

Examples:

SERP Preview:

- Meta Title Generator
- Meta Description Generator
- Open Graph Preview

Meta Tag Analyzer:

- SEO Score Checker
- Heading Checker
- Canonical Checker
- Open Graph Preview

Schema Generator:

- Schema Validator
- SEO Audit
- SERP Preview

Keyword tools:

- Search Intent Classifier
- Keyword Clustering
- Long-Tail Keyword Generator
- Content Brief Generator

Technical tools:

- Robots.txt Generator
- XML Sitemap Generator
- Redirect Checker
- Canonical Checker
- Hreflang Generator

---

# TOOL DISCOVERY

The homepage should have a section linking users to the Tools Hub.

Do not overcrowd the homepage with all 26 tools.

Feature a small selection of popular tools and link to:

`/tools/`

---

# INTERNAL LINKING STRATEGY

Build a connected tool ecosystem.

Examples:

Meta Title Generator
→ SERP Preview
→ Meta Description Generator

Meta Description Generator
→ SERP Preview
→ Meta Title Generator

Schema Generator
→ Schema Validator
→ SEO Audit

XML Sitemap Generator
→ Robots.txt Generator
→ SEO Audit

Keyword Clustering
→ Search Intent Classifier
→ Content Brief Generator

SEO Audit
→ Meta Tag Analyzer
→ Heading Checker
→ Canonical Checker
→ Image Alt Checker
→ Schema Validator

Use contextual internal links.

---

# EDUCATIONAL CONTENT

Each tool page must contain useful supporting content.

Do not create generic filler.

Each page should have:

### How to Use [Tool]

Short step-by-step instructions.

### What Is [Tool]?

Clear explanation.

### Why Does It Matter?

Explain practical SEO relevance.

### Best Practices

Useful recommendations.

### Common Mistakes

Specific mistakes related to that tool.

### FAQ

4–7 relevant questions.

Do not copy the same FAQ between every page.

---

# NO THIN CONTENT

The actual tool must be the primary purpose of each page.

The educational content supports the tool.

Do not create thousands of words purely to target keywords.

Prefer useful, concise explanations.

---

# ANALYTICS

If analytics already exist, preserve them.

Where practical, track tool interactions without collecting unnecessary personal data.

Useful events:

- Tool used
- Generate clicked
- Copy clicked
- Download clicked
- Analyze clicked
- Error encountered

Do not collect sensitive user information.

---

# ERROR HANDLING

Every tool must have:

- Empty state
- Loading state where applicable
- Error state
- Successful result state

Network-dependent tools must handle:

- Timeout
- CORS/backend failure
- Invalid URL
- Server error
- Rate limit
- Unreachable website

Explain the problem clearly.

Never show fake success.

---

# RATE LIMITING

For tools that perform server-side website requests:

Implement reasonable protections if backend support exists.

Examples:

- Maximum URLs per request
- Maximum links crawled
- Request timeout
- Rate limiting
- Response-size limits

Do not allow users to turn the website into an unrestricted URL-fetching proxy.

---

# DOWNLOAD FORMATS

Where appropriate:

XML Sitemap Generator:

`sitemap.xml`

Robots.txt:

`robots.txt`

Schema tools:

`.json`

Broken Link Checker:

`.csv`

Keyword tools:

`.csv` or `.txt`

Make downloads work in the browser where possible.

---

# ROUTING

Create routes for all 20 new tools.

Use the existing routing system.

Do not remove existing routes.

Verify direct URL access works for every route.

---

# 404 / FALLBACK

Ensure unknown tool URLs do not crash the application.

Use the existing 404 page if available.

---

# STRUCTURED DATA

For every tool page:

Use BreadcrumbList where appropriate.

Use appropriate WebPage/SoftwareApplication structured data only if accurate and useful.

Do not add fake ratings.

Do not add fake reviews.

Do not add fake aggregate ratings.

Do not add misleading Product schema.

---

# CANONICAL URLS

Use:

`https://rankwithajay.in/tools/meta-tag-analyzer/`

`https://rankwithajay.in/tools/xml-sitemap-generator/`

`https://rankwithajay.in/tools/seo-score-checker/`

`https://rankwithajay.in/tools/redirect-checker/`

`https://rankwithajay.in/tools/broken-link-checker/`

`https://rankwithajay.in/tools/keyword-density-checker/`

`https://rankwithajay.in/tools/heading-checker/`

`https://rankwithajay.in/tools/canonical-checker/`

`https://rankwithajay.in/tools/hreflang-generator/`

`https://rankwithajay.in/tools/http-status-checker/`

`https://rankwithajay.in/tools/image-alt-checker/`

`https://rankwithajay.in/tools/open-graph-preview/`

`https://rankwithajay.in/tools/search-intent-classifier/`

`https://rankwithajay.in/tools/keyword-clustering/`

`https://rankwithajay.in/tools/internal-link-checker/`

`https://rankwithajay.in/tools/seo-content-brief/`

`https://rankwithajay.in/tools/long-tail-keyword-generator/`

`https://rankwithajay.in/tools/schema-validator/`

`https://rankwithajay.in/tools/core-web-vitals/`

`https://rankwithajay.in/tools/website-seo-audit/`

Use trailing slashes consistently with the existing project.

---

# SITEMAP AND ROBOTS

If the project dynamically manages sitemap/robots configuration, update it so all indexable tool pages can be discovered.

Do not add noindex to the new tool pages.

Do not expose test/development routes in the sitemap.

---

# CODE QUALITY

Before finishing:

- Remove unused imports
- Remove dead code
- Avoid duplicated components
- Keep functions reasonably small
- Use clear naming
- Keep tool-specific logic isolated
- Keep reusable components centralized
- Avoid unnecessary dependencies

Do not rewrite working code without a reason.

---

# TESTING

Test all 26 tool routes.

At minimum verify:

### Existing

- Homepage
- Tools Hub
- SERP Preview
- Meta Title Generator
- Meta Description Generator
- Slug Generator
- Robots.txt Generator
- Schema Generator
- About Ajay

### New

- Meta Tag Analyzer
- XML Sitemap Generator
- SEO Score Checker
- Redirect Checker
- Broken Link Checker
- Keyword Density Checker
- Heading Checker
- Canonical Checker
- Hreflang Generator
- HTTP Status Checker
- Image Alt Checker
- Open Graph Preview
- Search Intent Classifier
- Keyword Clustering
- Internal Link Checker
- SEO Content Brief
- Long-Tail Keyword Generator
- Schema Validator
- Core Web Vitals
- Website SEO Audit

Test:

- Desktop
- Mobile
- Empty inputs
- Invalid inputs
- Valid inputs
- Copy buttons
- Download buttons
- Navigation
- Internal links
- Browser refresh
- Direct URL loading

---

# FINAL IMPORTANT REQUIREMENT

DO NOT pretend that functionality exists when the current Hostinger environment does not support it.

For example:

If arbitrary URL fetching requires a backend/API and the current project cannot perform it, do not return fake analysis.

Instead:

1. Build the complete frontend.
2. Create the appropriate backend/API abstraction if supported.
3. Clearly identify the remaining infrastructure requirement.
4. Keep the UI ready for real data.

Accuracy is more important than pretending every tool is fully functional.

---

# FINAL OUTPUT

After implementing everything, provide a concise implementation summary containing:

1. Tools successfully created
2. Routes created
3. Reusable components added
4. Backend/API functionality required
5. Any functionality that could not be completed
6. Any existing pages that were modified
7. Any issues that need manual configuration in Hostinger

Do not claim that everything is complete if anything is not actually functional.

The final website should feel like one coherent product:

**Rank With Ajay — Practical SEO Tools for Everyday SEO Work**