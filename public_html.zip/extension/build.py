from pathlib import Path
import re,json,html
ROOT=Path(__file__).resolve().parents[1]
brief=(ROOT/'extension/SPEC.md').read_text()
items=[]
for block in re.split(r'# TOOL \d+ — ',brief)[1:21]:
 name=block.splitlines()[0].title().replace('Seo','SEO').replace('Xml','XML').replace('Http','HTTP').replace('Url','URL')
 slug=re.search(r'`/tools/([^/]+)/`',block)[1]
 title=re.search(r'SEO title:\s*\*\*(.*?)\*\*',block,re.S)[1]
 items.append(dict(name=name,slug=slug,title=title))
notes=[
('Check metadata, headings and social tags from a webpage.','Review missing titles and descriptions before changing their length.','Meta tags describe a page to search engines and sharing platforms.','Check the rendered page too: JavaScript can change metadata.','Do not treat a length warning as a ranking penalty.'),
('Create a valid XML sitemap from your chosen URLs.','Add a URL for each indexable page, set optional dates and generate XML.','A sitemap lists URLs you want search engines to discover.','Use canonical, absolute URLs and truthful last-modified dates.','Do not include redirected, blocked or duplicate URLs.'),
('Run a transparent, ten-category on-page checklist.','Enter a page URL or paste its HTML, then inspect each check.','This score summarizes observable markup checks.','Address missing essentials before optimizing optional metadata.','Do not compare this diagnostic score with Google rankings.'),
('Inspect the HTTP redirect chain for one URL.','Enter the original URL and run the redirect check.','Redirects forward visitors and crawlers to another address.','Prefer a short chain ending on the intended destination.','Do not assume every redirect is permanent.'),
('Check links on one submitted page, with a bounded link limit.','Submit one page and review link status, anchor text and destination.','Broken links lead to destinations that return failure responses.','Verify reported failures before removing useful links.','A blocked request is not proof that a link is broken.'),
('Measure word and phrase repetition in your text.','Paste content and optionally enter a target phrase.','Keyword density describes the frequency of a term in a text.','Read repeated phrases in context before editing.','There is no universal keyword-density percentage that guarantees rankings.'),
('Inspect H1–H6 headings and their order.','Paste HTML or analyze a URL, then review the heading sequence.','Headings organize content into navigable sections.','Use descriptive headings and meaningful nesting.','Do not select heading levels only for their visual size.'),
('Inspect canonical tags and their target URLs.','Provide the source URL to compare its canonical with the page address.','A canonical tag signals a preferred version of similar pages.','Keep canonical targets consistent with internal links and sitemaps.','A canonical signal does not guarantee the URL Google selects.'),
('Generate alternate-language links for equivalent pages.','Add each URL and language, optionally add a region or x-default.','Hreflang describes localized versions of the same content.','Include the full reciprocal set on every alternate page.','Do not link unrelated pages or use a country without a language.'),
('Retrieve actual HTTP response details for a URL.','Enter a public HTTP or HTTPS URL and request a status check.','HTTP codes describe how a server handled a request.','Investigate persistent errors and confirm the final URL.','403 and 429 responses can reflect blocking or rate limits.'),
('Review image alt attributes, sizes and loading hints.','Analyze a page or paste HTML and inspect each image row.','Alternative text communicates an image’s purpose when it cannot be seen.','Describe informative images; use empty alt for decorative images.','Missing alt and intentionally empty alt are different cases.'),
('Preview Facebook, LinkedIn and generic social cards.','Enter a title, description, page URL, image URL and site name.','Open Graph metadata supplies information for social sharing cards.','Use a crawlable image and verify sharing previews on each platform.','Actual crops and cached previews can differ from this simulation.'),
('Estimate search intent with transparent keyword rules.','Enter a query and inspect the matching words and content suggestion.','Intent is the likely purpose behind a search query.','Validate ambiguous queries against actual search results.','Rule-based confidence is a heuristic, not a measured probability.'),
('Group keywords using approximate word-overlap clustering.','Paste one keyword per line, adjust the list and generate groups.','Clustering organizes related phrases for content planning.','Review groups manually before assigning page targets.','Word overlap does not establish perfect semantic similarity.'),
('Inspect internal and external links on one page.','Enter the page URL and review targets, anchors and nofollow attributes.','Internal links connect pages on the same host.','Use descriptive anchors and link to relevant destinations.','Relative links need the correct source URL to resolve properly.'),
('Generate an editable content outline from your inputs.','Add your keyword, audience, market and page type, then generate a brief.','A content brief aligns a writer on purpose, structure and next steps.','Add original expertise and verify the audience’s real questions.','Template outlines are starting points and do not guarantee rankings.'),
('Expand a seed topic into long-tail keyword ideas.','Enter a seed keyword and optionally add audience, location and intent.','Long-tail ideas combine a topic with more specific needs or modifiers.','Validate relevance and demand before creating pages.','Generated ideas contain no measured volume, CPC or difficulty.'),
('Check JSON-LD syntax and basic schema structure.','Paste JSON-LD or a JSON-LD script tag and validate it.','JSON-LD represents structured information about a page or entity.','Use supported types and match markup to visible page content.','Local checks do not guarantee Google rich-result eligibility.'),
('Check real LCP, INP and CLS measurements when a service is connected.','Enter a URL and request available field performance data.','Core Web Vitals describe loading, interaction and visual stability.','Distinguish real-user field measurements from lab diagnostics.','Missing field data is not a zero score or a passing result.'),
('Audit one webpage using observable technical and on-page checks.','Analyze a URL or paste HTML and expand the checklist categories.','A page audit highlights issues that warrant investigation.','Prioritize verified issues and retest after making changes.','This is a diagnostic aid, not a Google ranking score or ranking prediction.')]
onpage={0,2,5,6,7,10,11}; keywords={12,13,14,15,16}
for i,(t,n) in enumerate(zip(items,notes)):
 t.update(dict(zip(['description','how','what','best','mistake'],n)))
 t['category']='On-Page SEO' if i in onpage else 'Keyword & Content SEO' if i in keywords else 'Technical SEO'
 t['url']='/tools/'+t['slug']+'/'
 t['icon']=['<>','XML','✓','↪','↗','Aa','H1','↔','文','HTTP','ALT','OG','?','≋','↗','¶','+','{}','◷','✓'][i]
 t['related']=[q['slug'] for j,q in enumerate(items) if j!=i and (j in onpage if i in onpage else j in keywords if i in keywords else j not in onpage|keywords)][:4]
(ROOT/'extension/tools.json').write_text(json.dumps(items,indent=2))
esc=html.escape
header='<header class="site-header"><a class="brand" href="/">↗ <span>Rank With Ajay</span></a><nav aria-label="Main navigation"><a href="/">Home</a><a href="/tools/">SEO Tools</a><a href="/about-ajay/">About Ajay</a></nav><a class="button" href="/tools/">Explore Tools</a></header>'
footer='<footer><strong>Rank With Ajay</strong><p>Practical SEO tools and resources for better websites.</p><a href="/tools/">All SEO tools</a> · <a href="/about-ajay/">About Ajay</a> · <a href="/privacy/">Privacy Policy</a></footer>'
original=(ROOT/'index.html').read_text(); gtm=re.search(r'<!-- Google Tag Manager -->.*?<!-- End Google Tag Manager -->',original,re.S)[0]
def page(title,description,url,body,slug='hub'):
 canonical='https://rankwithajay.in'+url
 schema={'@context':'https://schema.org','@type':'BreadcrumbList','itemListElement':[{'@type':'ListItem','position':1,'name':'Home','item':'https://rankwithajay.in/'},{'@type':'ListItem','position':2,'name':'SEO Tools','item':'https://rankwithajay.in/tools/'}]}
 if slug!='hub': schema['itemListElement'].append({'@type':'ListItem','position':3,'name':next(t['name'] for t in items if t['slug']==slug),'item':canonical})
 return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{esc(title)}</title><meta name="description" content="{esc(description)}"><link rel="canonical" href="{canonical}"><meta property="og:title" content="{esc(title)}"><meta property="og:description" content="{esc(description)}"><meta property="og:url" content="{canonical}"><meta property="og:type" content="website"><link rel="icon" href="/favicon.svg"><link rel="stylesheet" href="/assets/index-E9r5RmEI.css"><link rel="stylesheet" href="/extension/tools-v1.css">{gtm}<script type="application/ld+json">{json.dumps(schema)}</script><script src="/extension/config-v1.js"></script><script defer src="/extension/tools-v1.js"></script></head><body data-tool="{slug}"><a class="skip" href="#main">Skip to content</a>{header}<main id="main">{body}</main>{footer}</body></html>'''
def cards(ts):
 return '<div class="cards">'+''.join(f'<a class="tool-card" href="{t["url"]}" data-name="{esc(t["name"].lower())}" data-category="{esc(t["category"])}"><span class="icon">{esc(t.get("icon","↗"))}</span><h3>{esc(t["name"])}</h3><p>{esc(t["description"])}</p><span class="card-action">Open tool →</span></a>' for t in ts)+'</div>'
for t in items:
 body=f'<div class="breadcrumb"><a href="/">Home</a> / <a href="/tools/">SEO Tools</a> / {esc(t["name"])}</div><section class="hero"><span class="eyebrow">{t["category"]}</span><h1>{t["name"]}</h1><p>{t["description"]}</p></section><section class="workspace" aria-label="{t["name"]} tool"><div id="tool-input"></div><div id="feedback" role="status" aria-live="polite"></div><section id="result" hidden aria-label="Results"></section></section><noscript>Enable JavaScript to use this tool. The guidance below remains available.</noscript>'
 body+=f'<section class="education"><h2>How to use {t["name"]}</h2><p>{t["how"]}</p><h2>What is {t["name"]}?</h2><p>{t["what"]}</p><h2>Why does it matter?</h2><p>{t["description"]} Use the findings to guide a focused review of your content or implementation.</p><h2>Best practices</h2><p>{t["best"]}</p><h2>Common mistakes</h2><p>{t["mistake"]}</p><h2>Frequently asked questions</h2>'
 faqs=[(f'How do I start using {t["name"]}?',t['how']),(f'What should I review after using {t["name"]}?',t['best']),(f'What is a common mistake with {t["name"]}?',t['mistake']),(f'What does {t["name"]} help me understand?',t['what'])]
 body+=''.join(f'<details><summary>{esc(q)}</summary><p>{esc(a)}</p></details>' for q,a in faqs)+'</section><section class="related"><h2>Related tools</h2>'+cards([q for q in items if q['slug'] in t['related']])+'</section>'
 path=ROOT/'tools'/t['slug'];path.mkdir(exist_ok=True)
 (path/'index.html').write_text(page(t['title'],t['description'],t['url'],body,t['slug']))
old=[('SERP Preview','serp-preview','Preview your title and description in search results.','On-Page SEO'),('Meta Title Generator','meta-title-generator','Draft title options for your page.','On-Page SEO'),('Meta Description Generator','meta-description-generator','Write useful search snippets.','On-Page SEO'),('Slug Generator','slug-generator','Create readable URL slugs.','On-Page SEO'),('Robots.txt Generator','robots-txt-generator','Create crawler directives.','Technical SEO'),('Schema Markup Generator','schema-generator','Generate structured data for your page.','Technical SEO')]
alltools=[dict(name=n,slug=s,url='/tools/'+s+'/',description=d,category=c) for n,s,d,c in old]+items
body='<section class="hero"><span class="eyebrow">Practical tools. Everyday SEO.</span><h1>SEO Tools</h1><p>26 focused tools for better websites. Choose a task and get to work.</p></section><section class="filters"><label>Find a tool<input id="search" type="search" placeholder="Search tools…"></label><label>Category<select id="category"><option>All categories</option><option>On-Page SEO</option><option>Technical SEO</option><option>Keyword &amp; Content SEO</option></select></label></section><p id="count" role="status">26 tools</p>'
for cat in ['On-Page SEO','Technical SEO','Keyword & Content SEO']:
 body+=f'<section class="tool-group"><h2>{esc(cat)}</h2>'+cards([t for t in alltools if t['category']==cat])+'</section>'
(ROOT/'tools/index.html').write_text(page('Free SEO Tools – 26 Practical Tools | Rank With Ajay','Explore on-page, technical, keyword and content SEO tools.','/tools/',body))
# Keep the original application intact. A small bridge sends SPA navigation to real added documents.
original=original.replace('<script defer src="/extension/legacy-bridge-v1.js"></script>','')
original=original.replace('</head>','<script defer src="/extension/legacy-bridge-v1.js"></script></head>')
(ROOT/'index.html').write_text(original)
sitemap=(ROOT/'sitemap.xml').read_text()
for t in items:
 if 'https://rankwithajay.in'+t['url'] not in sitemap:sitemap=sitemap.replace('</urlset>',f'<url><loc>https://rankwithajay.in{t["url"]}</loc></url>\n</urlset>')
(ROOT/'sitemap.xml').write_text(sitemap)

# Apply shared UI and the expanded browser generators after the baseline pages.
import runpy
runpy.run_path(str(ROOT/"extension/design.py"), run_name="__main__")
runpy.run_path(str(ROOT/"extension/build-generators.py"), run_name="__main__")
runpy.run_path(str(ROOT/"extension/launch.py"), run_name="__main__")

runpy.run_path(str(ROOT/"extension/premium.py"), run_name="__main__")

runpy.run_path(str(ROOT/"extension/platform-build.py"), run_name="__main__")
