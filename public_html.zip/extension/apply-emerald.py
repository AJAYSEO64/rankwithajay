from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
for p in root.rglob('*.html'):
 if 'core-web-vitals' in str(p):continue
 s=p.read_text()
 s=re.sub(r'<link[^>]+href="/extension/(?:seom-theme|emerald-theme)\.css[^>]*>','',s)
 s=s.replace('</head>','<link rel="stylesheet" href="/extension/emerald-theme.css?v=20260924"></head>')
 if p==root/'index.html' and 'blog-navigation.js' not in s:s=s.replace('</head>','<script src="/extension/blog-navigation.js?v=20260924"></script></head>')
 p.write_text(s)
