/* Presentation only. Tool calculations, requests, outputs and metadata are untouched. */
(() => {
 'use strict';
 const toggle=document.querySelector('.rwa-menu-toggle'),nav=document.querySelector('.rwa-nav');
 function closeMenu(){if(!toggle||!nav)return;nav.classList.remove('is-open');toggle.setAttribute('aria-expanded','false');toggle.textContent='Menu'}
 if(toggle&&nav){toggle.addEventListener('click',()=>{const open=toggle.getAttribute('aria-expanded')!=='true';toggle.setAttribute('aria-expanded',String(open));toggle.textContent=open?'Close':'Menu';nav.classList.toggle('is-open',open)});nav.addEventListener('click',e=>{if(e.target.closest('a'))closeMenu()});document.addEventListener('keydown',e=>{if(e.key==='Escape'&&toggle.getAttribute('aria-expanded')==='true'){closeMenu();toggle.focus()}});document.addEventListener('click',e=>{if(!e.target.closest('.rwa-header'))closeMenu()})}
 const search=document.querySelector('#search'),category=document.querySelector('#category'),empty=document.querySelector('#rwa-no-results');
 if(search&&category&&empty){const sync=()=>{empty.hidden=[...document.querySelectorAll('.tool-group .tool-card')].some(c=>!c.hidden)};search.addEventListener('input',sync);category.addEventListener('change',sync);document.querySelector('#rwa-clear-filters').addEventListener('click',()=>{search.value='';category.value='All categories';category.dispatchEvent(new Event('change',{bubbles:true}));search.dispatchEvent(new Event('input',{bubbles:true}));search.focus()});sync()}
 // A download click starts a browser download; never claim disk completion.
 document.addEventListener('click',e=>{const b=e.target.closest('button,a[download]');if(!b||b.disabled||!(/download/i.test(b.textContent)||b.hasAttribute('download')))return;const region=b.closest('.actions')||b.parentElement;if(!region)return;let note=region.querySelector('.rwa-inline-feedback');if(!note){note=document.createElement('span');note.className='rwa-inline-feedback';note.setAttribute('role','status');region.append(note)}note.textContent='Download requested';setTimeout(()=>{note.textContent=''},3000)});
 const root=document.getElementById('root');if(!root)return;
 function enhance(){
  const main=root.querySelector('main');if(!main)return;
  const path=location.pathname;const type=path==='/'?'home':path.startsWith('/about')?'profile':path.startsWith('/tools/')?'tool-page':'editorial';
  const cls='rwa-'+type;if(!root.classList.contains(cls)){root.classList.remove('rwa-home','rwa-profile','rwa-tool-page','rwa-editorial');root.classList.add(cls)}
  root.querySelectorAll('header nav a').forEach(a=>{const u=new URL(a.href,location.href);const active=u.pathname.replace(/\/$/,'')===path.replace(/\/$/,'')&&!u.hash;if(active&&a.getAttribute('aria-current')!=='page')a.setAttribute('aria-current','page');else if(!active&&a.hasAttribute('aria-current'))a.removeAttribute('aria-current')});
  if(path==='/'){
   const h=main.querySelector('h1'),hero=h?.closest('section');
   if(hero&&!hero.classList.contains('rwa-home-hero'))hero.classList.add('rwa-home-hero');
   const visual=hero?.querySelector('[aria-hidden="true"].relative');
   if(visual&&!visual.dataset.premium){visual.dataset.premium='true';visual.removeAttribute('aria-hidden');visual.className='rwa-product-preview';visual.innerHTML='<div class="rwa-preview-top"><strong>Your SEO workspace</strong><span>Preview example</span></div><div class="rwa-preview-result"><small>rankwithajay.in › tools</small><h3>Free SEO Tools to Help You Rank Better</h3><p>Write clearer metadata, create structured data and check the details that matter.</p></div><div class="rwa-preview-links"><a href="/tools/serp-preview/">SERP Preview ↗</a><a href="/tools/meta-title-generator/">Meta Title ↗</a><a href="/tools/meta-description-generator/">Meta Description ↗</a><a href="/tools/schema-generator/">Schema ↗</a><a href="/tools/robots-txt-generator/">Robots.txt ↗</a><a href="/tools/">All 28 tools ↗</a></div><p class="rwa-preview-caption">Illustrative search snippet. Actual search results may differ.</p>'}
  }
 }
 let queued=false;new MutationObserver(()=>{if(!queued){queued=true;requestAnimationFrame(()=>{queued=false;enhance()})}}).observe(root,{childList:true,subtree:true});enhance();
})();
