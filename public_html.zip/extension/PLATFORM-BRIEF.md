# MASTER UI/UX REDESIGN PROMPT — RANK WITH AJAY

You are working on my existing website:

**Brand:** Rank With Ajay
**Domain:** rankwithajay.in
**Website type:** Free SEO Tools + SEO Resources + Personal SEO Brand
**Current website:** Existing working website with approximately 28 SEO tools.

I want you to **redesign the website's UI/UX and visual design**.

IMPORTANT:

This is NOT a request to copy another website.

Use the following websites ONLY as design/UX references:

- [https://mangools.com/](https://mangools.com/)
- [https://smallseotools.com/](https://smallseotools.com/)
- [https://www.semrush.com/](https://www.semrush.com/)
- [https://ahrefs.com/](https://ahrefs.com/)
- [https://neilpatel.com/ubersuggest/](https://neilpatel.com/ubersuggest/)

Study their:

- Visual hierarchy
- Navigation
- Tool discovery
- Homepage structure
- Tool cards
- Search/filter experience
- Typography
- Spacing
- CTA placement
- Tool page structure
- Content organization
- Trust elements
- Responsive behavior
- Overall product feel

DO NOT copy:

- Their branding
- Their logo
- Their colors exactly
- Their layouts exactly
- Their illustrations
- Their text
- Their proprietary UI
- Their component designs
- Their exact navigation
- Their CSS
- Their visual identity

Create an ORIGINAL design system for:

# RANK WITH AJAY

The goal is to make Rank With Ajay feel like a **professional SEO software/tool platform**, not a basic collection of free online tools.

---

# 1. CORE DESIGN OBJECTIVE

Transform the existing website from a simple SEO tools website into:

**A polished, modern, trustworthy SEO toolkit platform.**

The website should feel like a smaller independent alternative to major SEO platforms.

The visual positioning should be:

**Professional SEO platform**
\+
**Free practical tools**
\+
**SEO expert personal brand**

The visitor should immediately think:

> "This is a serious SEO tools website."

Not:

> "This is just another collection of random free tools."

---

# 2. DESIGN INSPIRATION

Use the references strategically.

### Mangools

Take inspiration from:

- Clean product presentation
- Strong tool hierarchy
- Friendly but professional design
- Excellent whitespace
- Clear tool categories
- Strong tool discovery
- Educational content integrated with the product

Mangools currently presents its free SEO tools as a curated collection and combines tool discovery with educational SEO content. Use this type of information architecture as inspiration, but create an original implementation.

### Small SEO Tools

Take inspiration from:

- Large collection of tools
- Strong categorization
- Easy tool discovery
- Search-oriented interface
- Utility-first UX

But DO NOT reproduce its crowded visual style.

Rank With Ajay should be significantly cleaner and more premium.

### Semrush

Take inspiration from:

- Professional SaaS presentation
- Strong hierarchy
- Product-led sections
- Trust-building
- Clear CTAs
- Enterprise-quality visual polish

But Rank With Ajay should remain simpler and more accessible.

### Ahrefs

Take inspiration from:

- Strong typography
- Excellent spacing
- Clear content hierarchy
- Strong product storytelling
- Professional tool presentation
- Minimal unnecessary decoration

### Ubersuggest

Take inspiration from:

- SEO-focused positioning
- Simple tool-first interactions
- Beginner-friendly communication
- Personal expert branding

---

# 3. BRAND PERSONALITY

Rank With Ajay should have its own personality.

Brand characteristics:

- SEO expert
- Practical
- Helpful
- Technical
- Modern
- Trustworthy
- Independent
- Straightforward
- No unnecessary hype

Avoid:

- Corporate jargon
- Excessive marketing language
- Fake urgency
- Fake statistics
- Fake testimonials
- "AI-powered" claims unless the feature actually exists
- Generic startup language

---

# 4. GLOBAL VISUAL DIRECTION

Create a premium SEO SaaS visual system.

Use:

- Clean white/light backgrounds
- Strong dark typography
- One recognizable primary brand color
- Subtle secondary accent
- Light borders
- Soft shadows
- Moderate corner radius
- Generous whitespace
- Clear content containers
- Strong visual hierarchy

The design should be:

**Clean + premium + practical + modern**

Avoid:

- Excessive gradients
- Neon colors
- Glassmorphism everywhere
- Giant decorative blobs
- Excessive rounded pills
- Random illustrations
- Stock photos
- Over-animated backgrounds
- Excessive shadows

---

# 5. CREATE A REAL DESIGN SYSTEM

Do not redesign each page independently.

First create a reusable global design system.

Define:

### Colors

- Primary
- Primary hover
- Primary light
- Background
- Surface
- Surface secondary
- Text primary
- Text secondary
- Muted text
- Border
- Success
- Warning
- Error

### Typography

Create consistent:

- H1
- H2
- H3
- H4
- Body
- Small
- Caption
- Label

### Spacing

Use a consistent spacing scale.

### Components

Create reusable components for:

- Header
- Footer
- Buttons
- Cards
- Tool cards
- Inputs
- Textareas
- Selects
- Badges
- Alerts
- Breadcrumbs
- Tabs
- Accordions
- Result boxes
- Code blocks
- Copy buttons
- Search
- Filters
- Pagination where needed

---

# 6. HEADER

Completely improve the header.

Desktop navigation should feel like a real SEO platform.

Suggested structure:

LEFT:

**Rank With Ajay**

CENTER/RIGHT:

**Tools**
**SEO Guides**
**Blog**
**About Ajay**

Primary CTA:

**Explore Tools**

Do not make the header unnecessarily large.

Use:

- Clean spacing
- Strong typography
- Subtle border
- Active navigation states
- Hover states

Consider a Tools mega-menu/dropdown if it improves discoverability.

The Tools navigation could expose categories such as:

- On-Page SEO
- Technical SEO
- SERP & Metadata
- Schema
- URLs & Indexing
- Content SEO
- Other SEO Tools

Keep it simple.

---

# 7. HOMEPAGE HERO

The homepage must immediately communicate the product.

Use a strong hero such as:

## Free SEO Tools to Help You Rank Better

Supporting message:

Practical SEO tools for website owners, marketers, content creators and SEO professionals.

Do NOT make the hero too generic.

The hero should visually communicate that this website contains many useful SEO tools.

---

# 8. HERO TOOL INTERACTION

Create a visual tool discovery element in the hero.

For example:

A large search box:

**What SEO tool do you need?**

Placeholder:

**Search SEO tools...**

Below it:

Popular:

**SERP Preview**
**Meta Title Generator**
**Schema Generator**
**Slug Generator**

This makes the website feel like a real tool platform.

---

# 9. HERO VISUAL

Create a subtle product-style visual.

Possible concept:

A floating dashboard-style composition showing:

- SEO score
- SERP preview
- Meta title
- Meta description
- URL
- Schema
- Ranking indicator

It should visually communicate:

**SEO tools**

Do NOT use random stock images.

Do NOT use a generic person sitting at a laptop.

Do NOT create a huge decorative illustration that distracts from the tools.

---

# 10. TRUST STRIP

Immediately below the hero, create a compact trust/value strip.

Examples:

**28+ SEO Tools**
**Free to Use**
**No Signup Required**
**Built for Practical SEO**

Only use claims that are actually true.

Do not fabricate numbers.

---

# 11. FEATURED TOOLS

This should become one of the strongest sections of the homepage.

Heading:

## Popular SEO Tools

Supporting text:

Quickly access the tools SEOs use most often.

Create a premium grid.

Each card:

ICON

Tool Name

One-line description

Category label

Arrow

Example:

### SERP Preview

Preview your title, URL and description in a Google-style search result.

**Try Tool →**

Cards should feel like products, not blog posts.

---

# 12. TOOL CARD DESIGN

Create a strong reusable ToolCard.

Structure:

┌──────────────────────────────────────┐
│ ICON │
│ │
│ SERP Preview │
│ Preview how your search snippet │
│ may appear in Google. │
│ │
│ SERP & Metadata → │
└──────────────────────────────────────┘

Hover:

- Border changes subtly
- Slight elevation
- Arrow moves slightly
- Icon may shift subtly

Do not use excessive animation.

---

# 13. COMPLETE TOOLS SECTION

Create a major homepage section:

# Explore All SEO Tools

Include:

### Search

"Search SEO tools..."

### Category filters

- All Tools
- On-Page SEO
- Technical SEO
- Metadata
- SERP
- Schema
- URLs
- Content
- Other

Then show the tool grid.

The experience should resemble a professional SEO platform's tool directory.

---

# 14. TOOLS PAGE

Redesign:

`/tools/`

as a dedicated **SEO Tools Hub**.

Top:

Breadcrumb

H1:

**Free SEO Tools**

Description:

Explore practical SEO tools for optimizing websites, search snippets, URLs, structured data and more.

Then:

SEARCH

CATEGORY FILTERS

TOOL GRID

The tool directory should be one of the strongest pages on the website.

---

# 15. TOOL DIRECTORY SEARCH

The search experience should feel instant.

Example:

User types:

`meta`

Results:

- Meta Title Generator
- Meta Description Generator
- Meta Robots Generator
- Open Graph Generator

If user types:

`schema`

show schema-related tools.

Include:

**No tools found**

with a helpful message if there are no results.

---

# 16. CATEGORY DESIGN

Do not dump all 28 tools into one visually overwhelming grid.

Group them logically.

Possible categories:

### On-Page SEO

### SERP & Metadata

### Technical SEO

### Schema & Structured Data

### URLs & Indexing

### Content SEO

### Social & Sharing

### SEO Utilities

Use the actual tools that exist in the project.

Do not invent tools that are not implemented.

---

# 17. INDIVIDUAL TOOL PAGE

Every tool page should use a common premium layout.

Structure:

Breadcrumb

Tool title

Short description

Main tool interface

Result

How to use

SEO explanation

Best practices

FAQ

Related tools

---

# 18. TOOL INTERFACE

The actual tool should be visually dominant.

Do not bury the tool below a huge amount of text.

Example:

## Meta Title Generator

Create SEO-friendly title tag ideas based on your keyword, topic and search intent.

Then immediately:

INPUT PANEL

Keyword:
[\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_]

Search intent:
[ Informational ▼ ]

Tone:
[ Professional ▼ ]

[ Generate Titles ]

Then:

RESULTS

Generated title suggestions

[Copy]

---

# 19. TOOL RESULT DESIGN

Generated results should look valuable.

Use cards such as:

### Suggested Title #1

Your generated SEO title here

**Copy**

### Suggested Title #2

Your generated SEO title here

**Copy**

For code-based tools, use:

```text
<code>
...
</code>

```

with:

**Copy Code**

The result area should visually stand apart from the input.

---

# 20. TOOL PAGES SHOULD FEEL LIKE PRODUCTS

Every tool needs:

- Clear title
- Clear value proposition
- Clear input
- Clear action
- Clear output
- Clear next step

The visitor should never wonder:

"What am I supposed to do here?"

---

# 21. SERP PREVIEW

Make the SERP Preview tool one of the flagship experiences.

Layout:

LEFT:

Title input

URL input

Description input

Metrics

RIGHT:

Live Google-style preview

On smaller screens:

Inputs first

Preview second

Make the preview look polished and realistic.

Use the existing SERP rendering logic.

Do not claim that the preview exactly reproduces Google's live rendering.

---

# 22. GENERATOR TOOLS

Use the same design language for:

- Meta Title Generator
- Meta Description Generator
- Slug Generator
- Canonical URL Generator
- Hreflang Generator
- Open Graph Generator
- Meta Robots Generator
- Schema Generator
- Robots.txt Generator

Each should feel like part of the same platform.

---

# 23. TOOL STATUS / FEEDBACK

Improve micro-interactions.

Copy:

**Copy → Copied**

Generate:

**Generate → Generating → Generated**

Validation:

Use clear inline errors.

Do not rely on browser default alerts.

---

# 24. EDUCATIONAL CONTENT

After the tool, create a professional educational section.

Example:

## What is a Meta Title?

Short explanation.

## Why does it matter for SEO?

Short explanation.

## How to use this tool

1. Enter your keyword.
2. Choose your preferences.
3. Generate suggestions.
4. Review the result.
5. Copy the best option.

Then:

## SEO Best Practices

Use short bullet points.

This makes each tool page useful for both users and organic search.

---

# 25. RELATED TOOLS

At the bottom:

## You May Also Need

Show 3–4 relevant tools.

Example:

SERP Preview →

Meta Title Generator →

Meta Description Generator →

Open Graph Generator →

This should encourage users to continue using the platform.

---

# 26. SEO GUIDES

Create a strong content ecosystem.

Homepage section:

## Learn SEO

Cards:

- SEO Guides
- Technical SEO
- On-Page SEO
- Keyword Research
- Content Optimization
- Google Search Console

Use a professional editorial design.

---

# 27. BLOG

Make the blog look like a serious SEO publication.

Use:

Featured article

Then:

Article grid

Each article card:

Category

Title

Short description

Date

Reading time if available

Read article →

Avoid generic blog layouts.

---

# 28. ABOUT AJAY

The About Ajay page should establish the person behind the platform.

Design it as:

**SEO Expert + Builder + Practitioner**

Create:

Hero

About

Experience timeline

Skills

Tools/platforms

Selected SEO results

Certifications

Why Rank With Ajay

CTA to explore tools

Do not make this look like a generic resume.

It should feel like the founder/expert behind a real SEO product.

---

# 29. RESULTS / CREDIBILITY

Where verified data already exists, use visual metric cards.

Examples:

**100+**
Keywords ranked #1

**33K+**
Organic clicks

**25%+**
Average organic traffic lift

Only use the existing verified information in the project.

Never invent metrics.

---

# 30. HOMEPAGE STRUCTURE

The final homepage should follow approximately:

HEADER

↓

HERO

"Free SEO Tools to Help You Rank Better"

↓

TOOL SEARCH

"Search SEO tools..."

↓

TRUST / VALUE STRIP

↓

POPULAR TOOLS

↓

ALL TOOLS / CATEGORIES

↓

WHY RANK WITH AJAY

↓

HOW IT WORKS

↓

SEO GUIDES

↓

ABOUT AJAY / EXPERT CREDIBILITY

↓

FAQ

↓

FINAL CTA

↓

FOOTER

Do not blindly follow this exact structure if the existing content suggests a better hierarchy.

---

# 31. FINAL CTA

Create a strong but non-aggressive final section.

Example:

## Ready to improve your SEO?

Explore free SEO tools built for practical everyday optimization.

[Explore SEO Tools]

No fake urgency.

No fake discounts.

No unnecessary signup pressure.

---

# 32. FOOTER

Professional multi-column footer.

Column 1:

Rank With Ajay

Short brand description.

Column 2:

SEO Tools

- All Tools
- Popular Tools
- Tool Categories

Column 3:

Resources

- SEO Guides
- Blog
- About Ajay

Column 4:

Legal

- Privacy
- Terms
- Contact

Bottom:

© Rank With Ajay

---

# 33. RESPONSIVE DESIGN

Design intentionally for:

1440px
1280px
1024px
768px
430px
390px
375px
360px

Mobile should NOT look like a compressed desktop website.

Mobile priorities:

1. Tool discovery
2. Tool usability
3. Readability
4. Navigation
5. Copy actions

---

# 34. MOBILE HEADER

On mobile:

Logo

Menu

CTA if appropriate

Navigation should open as a clean full-width/mobile menu.

Tool categories should remain easy to access.

---

# 35. MOBILE TOOL INTERFACE

Every tool must be easy to operate with one hand.

Inputs:

Full width

Buttons:

Comfortable touch targets

Results:

Easy to copy

Code:

Horizontally scrollable where required

Never allow accidental horizontal page overflow.

---

# 36. PERFORMANCE

The new design must remain lightweight.

DO NOT add:

- Heavy animation libraries
- Huge image libraries
- Video backgrounds
- Unnecessary JavaScript
- Excessive external fonts
- Large decorative assets

Use CSS and existing project infrastructure wherever possible.

---

# 37. ACCESSIBILITY

Ensure:

- WCAG-conscious contrast
- Keyboard navigation
- Visible focus states
- Proper labels
- Semantic HTML
- Accessible buttons
- Accessible form controls
- Proper heading hierarchy
- Screen reader-friendly elements

---

# 38. SEO PRESERVATION

THIS IS EXTREMELY IMPORTANT.

Do NOT break existing SEO.

Preserve:

- Existing routes
- Existing URLs
- Existing metadata
- Existing title tags
- Existing meta descriptions
- Existing canonical tags
- Existing schema
- Existing breadcrumbs
- Existing internal links
- Existing tool content
- Existing structured data
- Existing robots functionality

Do not rename URLs.

Do not create duplicate routes.

Do not remove useful SEO content simply to make the design cleaner.

---

# 39. DO NOT CHANGE TOOL LOGIC

The redesign should primarily affect:

- Layout
- Components
- Styling
- Navigation
- UX
- Visual hierarchy
- Responsive behavior
- Micro-interactions

Do not rewrite working SEO algorithms unless required for the UI.

Existing tool functionality must continue working.

---

# 40. DO NOT USE GENERIC AI WEBSITE DESIGN

This is extremely important.

Do not create the typical:

"purple gradient + floating blobs + giant heading + glass cards + AI sparkle icons"

design.

Rank With Ajay is an SEO platform.

The design should feel:

**credible, useful, data-driven and professional.**

---

# 41. DESIGN DIFFERENTIATION

The references are inspiration only.

Create a unique Rank With Ajay identity.

Potential visual identity:

- Strong dark typography
- Clean light backgrounds
- Distinctive primary accent
- Subtle SEO/data-inspired visual details
- Clean tool cards
- Strong product screenshots
- Minimal but purposeful illustrations
- Excellent typography

The website should be recognizable without the logo.

---

# 42. PRODUCT FEEL

The most important change:

Make the website feel like a **product**, not a collection of webpages.

Every component should reinforce this.

Tool cards should feel like products.

Tool pages should feel like applications.

Search should feel like product navigation.

Results should feel like useful output.

The entire website should feel like one connected SEO platform.

---

# 43. DESIGN PRIORITY

Prioritize the work in this order:

### Priority 1

Global design system

### Priority 2

Header/navigation

### Priority 3

Homepage

### Priority 4

Tools directory

### Priority 5

Tool page layout

### Priority 6

Tool cards

### Priority 7

Forms/results

### Priority 8

About Ajay

### Priority 9

Blog/guides

### Priority 10

Footer and secondary pages

---

# 44. IMPORTANT: INSPECT BEFORE MODIFYING

Before changing anything:

1. Inspect the complete existing application.
2. Understand all current routes.
3. Identify all 28 existing tools.
4. Identify existing reusable components.
5. Identify existing design tokens.
6. Identify existing SEO components.
7. Identify existing tool logic.
8. Identify existing responsive behavior.
9. Identify existing homepage sections.

Do not blindly overwrite existing code.

Reuse working components whenever possible.

---

# 45. DO NOT REMOVE CONTENT

Do not remove useful existing content just because the design changes.

If a section is visually weak:

REDESIGN IT.

Do not automatically delete it.

If content needs restructuring:

REORGANIZE IT.

Do not unnecessarily rewrite it.

---

# 46. FINAL QUALITY STANDARD

Before completing the redesign, compare the overall EXPERIENCE — not the exact design — against the quality level of:

Mangools
Small SEO Tools
Semrush
Ahrefs
Ubersuggest

Ask:

- Does Rank With Ajay look like a real SEO platform?
- Can users find tools quickly?
- Does the homepage communicate the product immediately?
- Do the tools feel valuable?
- Does the UI feel consistent?
- Does the website look trustworthy?
- Does the website look professional enough to compete in SEO search results?
- Does it work beautifully on mobile?
- Does it feel like one unified product?

If the answer is no, continue improving the UI.

---

# FINAL INSTRUCTION

Do NOT copy the reference websites.

Instead:

**Study their product thinking.**
**Study their information architecture.**
**Study their UX patterns.**
**Study their visual hierarchy.**
**Study how they present SEO tools.**

Then create an original, premium:

# RANK WITH AJAY SEO PLATFORM

with a design quality that feels significantly more polished than a typical free SEO tools website.

The final result should make users want to:

**Discover a tool → Use the tool → Get a result → Try another tool → Read an SEO guide → Return again.**

That is the core UX loop.