/* Progressive presentation: content stays visible before and without JavaScript. */
(() => {
  'use strict';
  if (!window.matchMedia || !window.IntersectionObserver) return;
  const preference = window.matchMedia('(prefers-reduced-motion: reduce)');
  const selector = '.hero,.rwa-home-hero,.rwa-section-heading,.group-heading,.tool-card,.rwa-home-card,.rwa-values,.blog-intro,.blog-feature,.blog-cta,.article-title,.myth,.education,.final-cta';
  const seen = new WeakSet();
  const pending = new Set();
  const observer = new IntersectionObserver(entries => {
    for (const entry of entries) {
      if (!entry.isIntersecting) continue;
      observer.unobserve(entry.target);
      pending.delete(entry.target);
      if (preference.matches) continue;
      entry.target.classList.add('rwa-motion-enter');
      entry.target.addEventListener('animationend', () => entry.target.classList.remove('rwa-motion-enter'), {once:true});
    }
  }, {threshold: 0.06});
  function register(node) {
    if (!(node instanceof Element)) return;
    const targets = [...(node.matches(selector) ? [node] : []), ...node.querySelectorAll(selector)];
    for (const target of targets) {
      if (seen.has(target)) continue;
      seen.add(target);
      if (!preference.matches) {pending.add(target);observer.observe(target);}
    }
  }
  register(document.body);
  // New React routes and generated directory cards receive the same treatment.
  new MutationObserver(records => {
    for (const record of records) {
      record.addedNodes.forEach(register);
    }
    for (const target of pending) {
      if (!target.isConnected) {observer.unobserve(target);pending.delete(target);}
    }
  }).observe(document.body, {childList:true,subtree:true});
  preference.addEventListener('change', () => {
    if (!preference.matches) return;
    observer.disconnect();pending.clear();
    document.querySelectorAll('.rwa-motion-enter').forEach(el => el.classList.remove('rwa-motion-enter'));
  });
})();
