I want to add five new production-ready SEO tools to the existing **Rank With Ajay** website.

Website:

**rankwithajay.in**

Build these five tools:

1. `/tools/slug-generator/`
2. `/tools/canonical-url-generator/`
3. `/tools/hreflang-generator/`
4. `/tools/open-graph-generator/`
5. `/tools/meta-robots-generator/`

## CRITICAL REQUIREMENT

This is an existing project.

**Do NOT rebuild the website.**

**Do NOT change the existing design system unnecessarily.**

**Do NOT break any existing functionality.**

Existing tools that must continue working:

- `/tools/`
- `/tools/serp-preview/`
- `/tools/meta-title-generator/`
- `/tools/meta-description-generator/`
- `/tools/robots-txt-generator/`
- `/tools/schema-generator/`
- `/about-ajay/`

Reuse the existing:

- Header
- Footer
- SEO component
- Tool page layout
- Buttons
- Cards
- Input components
- Typography
- Spacing
- Colors
- Responsive system
- Utility functions

If reusable components already exist, extend them instead of creating duplicates.

All five tools must feel like part of the same Rank With Ajay product.

---

# GLOBAL REQUIREMENTS FOR ALL FIVE TOOLS

Every tool page must contain:

1. Breadcrumb
2. H1
3. Short introduction
4. Tool interface
5. Results/output
6. Copy button
7. Clear/reset button
8. Helpful explanation
9. How-to section
10. Best-practice section
11. FAQ
12. Related tools
13. Final CTA

All functionality must work **without an external API**.

The tools should run primarily in the browser.

Do not add unnecessary API calls.

Do not require users to create accounts.

Do not add artificial usage limits.

---

# COMMON TOOL UI

Use a consistent tool layout.

Desktop:

```text
┌──────────────────────────┬──────────────────────────┐
│                          │                          │
│ INPUT / SETTINGS         │ OUTPUT                  │
│                          │                          │
│                          │                          │
└──────────────────────────┴──────────────────────────┘

```

On smaller screens:

```text
INPUT
↓
OUTPUT

```

Use clear labels.

Do not rely on placeholders as labels.

Use helpful validation.

Use live updates where practical.

---

# TOOL 1 — SEO SLUG GENERATOR

URL:

`/tools/slug-generator/`

Page title:

**SEO Slug Generator – Create Clean URL Slugs | Rank With Ajay**

Meta description:

**Create clean, SEO-friendly URL slugs from page titles or keywords. Remove unnecessary characters, format URLs and copy your optimized slug for free.**

Canonical:

`https://rankwithajay.in/tools/slug-generator/`

## H1

**SEO Slug Generator**

Intro:

**Create clean, readable and SEO-friendly URL slugs from page titles, keywords or phrases.**

---

## INPUTS

### Page Title or Text

Textarea/input:

Placeholder:

`How to Create an SEO-Friendly Website for Beginners`

### Optional Keyword

Input:

`seo-friendly website`

### Options

Checkboxes:

- Convert to lowercase
- Replace spaces with hyphens
- Remove special characters
- Remove duplicate hyphens
- Remove leading/trailing hyphens
- Remove common stop words

Defaults should be sensible.

---

## OUTPUT

Show:

**Generated Slug**

Example:

`how-to-create-an-seo-friendly-website-for-beginners`

Also show:

**Character count**

and:

**URL preview**

Example:

`https://example.com/how-to-create-an-seo-friendly-website-for-beginners`

Allow the generated slug to be manually edited.

Changes to the editable slug should update the preview immediately.

Buttons:

**Copy Slug**

**Copy Full URL**

**Clear**

---

## SLUG LOGIC

Implement robust browser-side slugification.

Handle:

- Uppercase letters
- Lowercase conversion
- Spaces
- Multiple spaces
- Punctuation
- Special characters
- Unicode characters
- Accented characters
- Duplicate hyphens
- Leading/trailing hyphens

For Latin characters, normalize accented characters where appropriate.

Do not blindly remove meaningful non-Latin characters.

Do not claim that every URL must contain only ASCII characters.

---

## EDUCATIONAL CONTENT

H2:

**What Is an SEO Slug?**

Explain clearly.

H2:

**How to Create an SEO-Friendly URL Slug**

Cover:

- Keep URLs readable
- Describe the page
- Avoid unnecessary parameters where possible
- Use meaningful words
- Avoid excessive length
- Use consistent formatting
- Don't keyword stuff

H2:

**SEO URL Slug Best Practices**

H2:

**Common URL Mistakes**

FAQ:

- What is a URL slug?
- Should URL slugs contain keywords?
- Should I use hyphens or underscores?
- Should URL slugs be lowercase?
- How long should a URL slug be?
- Can I change an existing URL slug?

Do not make unsupported ranking guarantees.

---

# TOOL 2 — CANONICAL URL GENERATOR

URL:

`/tools/canonical-url-generator/`

Page title:

**Canonical URL Generator – Create Canonical Tags | Rank With Ajay**

Meta description:

**Generate a canonical URL and HTML canonical tag for your web pages. Create clean rel=canonical markup with this free technical SEO tool.**

Canonical:

`https://rankwithajay.in/tools/canonical-url-generator/`

## H1

**Canonical URL Generator**

Intro:

**Generate a canonical URL and ready-to-use rel="canonical" HTML tag for your webpage.**

---

## INPUTS

### Page URL

Input:

`https://example.com/example-page/`

### Options

Provide useful controls:

**Protocol**

- HTTPS
- HTTP

Default:

HTTPS

**Trailing slash**

- Keep
- Remove

**Query parameters**

Provide:

- Keep query parameters
- Remove query parameters

Default:

Keep the original URL unless the user explicitly selects another option.

Do NOT automatically remove parameters without telling the user.

---

## OUTPUT

Show:

### Canonical URL

```text
https://example.com/example-page/

```

### HTML

```html
<link rel="canonical" href="https://example.com/example-page/" />

```

Buttons:

**Copy URL**

**Copy HTML**

**Clear**

---

## VALIDATION

Detect:

- Empty URL
- Invalid URL
- Missing protocol
- Unsupported protocol
- Obvious malformed URL

Provide helpful messages.

Do not claim that generating a canonical tag means the canonical is automatically correct.

---

## EDUCATIONAL CONTENT

H2:

**What Is a Canonical URL?**

H2:

**Why Are Canonical Tags Used?**

H2:

**How to Use a Canonical Tag**

H2:

**Canonical URL Best Practices**

Explain important concepts including:

- Self-referencing canonicals
- Duplicate/near-duplicate pages
- Absolute URLs
- HTTPS consistency
- Avoiding conflicting canonical signals

FAQ:

- What is a canonical URL?
- What does rel="canonical" mean?
- Should every page have a canonical tag?
- Can canonical URLs point to another domain?
- Should canonical URLs use HTTPS?
- Can canonical tags fix duplicate content completely?

Keep explanations technically accurate and avoid guarantees.

---

# TOOL 3 — HREFLANG GENERATOR

URL:

`/tools/hreflang-generator/`

Page title:

**Hreflang Generator – Create Hreflang Tags | Rank With Ajay**

Meta description:

**Generate hreflang tags for multilingual and multi-regional websites. Add language, region and x-default URLs and copy the HTML markup for free.**

Canonical:

`https://rankwithajay.in/tools/hreflang-generator/`

## H1

**Hreflang Generator**

Intro:

**Generate hreflang tags for multilingual and multi-regional websites and create ready-to-use HTML link elements.**

---

## LANGUAGE/URL TABLE

Create a dynamic table.

Columns:

**Language**

**Region**

**URL**

**Remove**

Example:

| LanguageRegionURL |    |                                                          |
| ----------------- | -- | -------------------------------------------------------- |
| English           | US | [https://example.com/en-us/](https://example.com/en-us/) |
| English           | GB | [https://example.com/en-gb/](https://example.com/en-gb/) |
| French            | FR | [https://example.com/fr/](https://example.com/fr/)       |

Allow:

**+ Add Language**

---

## LANGUAGE

Provide a select/searchable input containing common language codes.

Examples:

- en
- fr
- de
- es
- it
- pt
- nl
- ja
- ko
- ar
- hi
- ml

Allow custom valid language codes where appropriate.

---

## REGION

Allow optional region code.

Examples:

- US
- GB
- IN
- AU
- CA
- AE
- QA

Generate:

`en-US`

or:

`en`

depending on the user's selection.

Do not force a region when it isn't required.

---

## X-DEFAULT

Add checkbox:

**Add x-default**

When enabled, display an additional URL input:

**x-default URL**

Generate:

```html
<link rel="alternate" hreflang="x-default" href="https://example.com/" />

```

---

## VALIDATION

Detect:

- Duplicate hreflang values
- Duplicate URLs
- Missing URLs
- Invalid URLs
- Missing language
- Invalid combinations
- Empty rows

Show clear warnings.

Do not prevent users from generating markup unless the input is fundamentally invalid.

---

## OUTPUT

Generate HTML:

```html
<link rel="alternate" hreflang="en-US" href="https://example.com/en-us/" />
<link rel="alternate" hreflang="en-GB" href="https://example.com/en-gb/" />
<link rel="alternate" hreflang="fr-FR" href="https://example.com/fr/" />
<link rel="alternate" hreflang="x-default" href="https://example.com/" />

```

Buttons:

**Copy HTML**

**Download HTML**

**Clear**

---

## IMPORTANT HREFLANG UX

Add a short warning:

**Hreflang implementation requires reciprocal/return references between alternate pages. This generator creates the markup, but you should verify the implementation across the relevant URLs.**

Do not claim that generating the tags alone guarantees correct international SEO.

---

## EDUCATIONAL CONTENT

H2:

**What Is Hreflang?**

H2:

**When Should You Use Hreflang?**

H2:

**How to Implement Hreflang**

H2:

**Common Hreflang Mistakes**

FAQ:

- What is hreflang?
- What is the difference between language and region codes?
- What is x-default?
- Do hreflang tags need to be reciprocal?
- Can hreflang be used for different countries?
- Can I use hreflang for similar English pages?

---

# TOOL 4 — OPEN GRAPH GENERATOR

URL:

`/tools/open-graph-generator/`

Page title:

**Open Graph Generator – Create OG Meta Tags | Rank With Ajay**

Meta description:

**Generate Open Graph and social sharing meta tags for your webpages. Preview your title, description and image and copy ready-to-use HTML.**

Canonical:

`https://rankwithajay.in/tools/open-graph-generator/`

## H1

**Open Graph Generator**

Intro:

**Create Open Graph meta tags and preview how your page may appear when shared on social platforms.**

---

## INPUTS

### Page Title

Placeholder:

`Your Page Title`

### Description

Textarea.

### URL

Placeholder:

`https://example.com/page/`

### Image URL

Placeholder:

`https://example.com/images/social-image.jpg`

### Site Name

Optional.

### Locale

Default:

`en_US`

### Content Type

Options:

- website
- article
- product

Default:

website

---

## TWITTER/X OPTIONS

Create an expandable section:

**Twitter/X Card**

Options:

- summary
- summary\_large\_image

Default:

summary\_large\_image

Inputs:

- Twitter/X title
- Twitter/X description
- Twitter/X image

If left empty, use the Open Graph values.

---

# LIVE SOCIAL PREVIEW

Create a visual preview.

Show:

- Image placeholder/image
- Site name
- Title
- Description
- URL/domain

The preview must update live.

If an image URL is invalid, show a graceful placeholder.

Do not allow broken images to destroy the layout.

Provide:

**Facebook/Generic Social Preview**

and:

**Twitter/X Preview**

Use platform-inspired layouts without claiming pixel-perfect replication of the live platforms.

Add:

**Preview only. Actual appearance may vary by platform, device and app.**

---

# OUTPUT

Generate:

```html
<meta property="og:title" content="..." />
<meta property="og:description" content="..." />
<meta property="og:url" content="..." />
<meta property="og:image" content="..." />
<meta property="og:site_name" content="..." />
<meta property="og:type" content="website" />
<meta property="og:locale" content="en_US" />

<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="..." />
<meta name="twitter:description" content="..." />
<meta name="twitter:image" content="..." />

```

Only generate tags for fields that have meaningful values.

Escape HTML attribute values safely.

Buttons:

**Copy HTML**

**Clear**

---

## EDUCATIONAL CONTENT

H2:

**What Are Open Graph Tags?**

H2:

**Why Are Open Graph Tags Important?**

H2:

**Open Graph Best Practices**

H2:

**Recommended Social Image Practices**

Do not state unsupported universal image dimensions as mandatory.

FAQ:

- What is Open Graph?
- What does og\:title do?
- What does og\:image do?
- What image should I use for social sharing?
- What is a Twitter/X card?
- Do Open Graph tags affect Google rankings?

---

# TOOL 5 — META ROBOTS GENERATOR

URL:

`/tools/meta-robots-generator/`

Page title:

**Meta Robots Tag Generator – Create Robots Meta Tags | Rank With Ajay**

Meta description:

**Generate meta robots tags for controlling how search engines may crawl, index and display your pages. Create ready-to-use robots directives for free.**

Canonical:

`https://rankwithajay.in/tools/meta-robots-generator/`

## H1

**Meta Robots Tag Generator**

Intro:

**Create a meta robots tag using simple controls for indexing, following links and search-result display directives.**

---

# INPUT CONTROLS

Create a clear visual control panel.

### INDEXING

Radio/select:

- index
- noindex

Default:

index

### LINKS

- follow
- nofollow

Default:

follow

### SNIPPET

Checkbox/options:

- Allow normal snippet
- nosnippet
- max-snippet

For max-snippet, allow a number input.

### VIDEO PREVIEW

Options:

- No restriction
- max-video-preview

Allow a number.

### IMAGE PREVIEW

Options:

- No restriction
- none
- standard
- large

### ARCHIVE

Provide appropriate support only if technically relevant to modern search-engine directives.

Avoid outdated or misleading directives.

---

# LIVE GENERATED TAG

Example:

```html
<meta name="robots" content="index, follow" />

```

If the user selects:

noindex + nofollow:

```html
<meta name="robots" content="noindex, nofollow" />

```

Show the generated directive in a code block.

Buttons:

**Copy HTML**

**Clear**

---

# DIRECTIVE EXPLANATION

Below the generated tag, show a plain-language explanation.

Example:

**Current directive**

`noindex, nofollow`

**Meaning**

Search engines are instructed not to index the page and not to follow links on the page.

Make this update dynamically.

---

# VALIDATION / WARNINGS

If users select potentially contradictory or unnecessary combinations, explain them.

Do not silently override user choices.

Examples:

If `noindex` is selected:

**This directive tells compliant search engines not to index the page.**

If `nofollow` is selected:

**This directive asks compliant search engines not to follow links on the page.**

Add a general note:

**Meta robots directives are instructions to search engines; they do not provide access control or security.**

---

# EDUCATIONAL CONTENT

H2:

**What Is a Meta Robots Tag?**

H2:

**How Does the Meta Robots Tag Work?**

H2:

**Noindex vs Nofollow**

H2:

**Meta Robots vs robots.txt**

This comparison is important.

Explain that:

- robots.txt controls crawling access
- meta robots directives communicate indexing/display instructions when the page can be accessed
- they are not interchangeable

FAQ:

- What is a meta robots tag?
- What does noindex mean?
- What does nofollow mean?
- What is the difference between robots.txt and meta robots?
- Should every page have a meta robots tag?
- Can meta robots prevent a page from being crawled?

---

# RELATED TOOLS

At the bottom of EVERY new tool page, create a consistent related-tools section.

Include:

**SERP Preview Tool**

`/tools/serp-preview/`

**Meta Title Generator**

`/tools/meta-title-generator/`

**Meta Description Generator**

`/tools/meta-description-generator/`

**Robots.txt Generator**

`/tools/robots-txt-generator/`

**Schema Markup Generator**

`/tools/schema-generator/`

For the new tools, also cross-link where relevant:

Slug Generator
Canonical URL Generator
Hreflang Generator
Open Graph Generator
Meta Robots Generator

Do not create fake links.

Use the exact routes specified in this prompt.

---

# TOOLS HUB

Update `/tools/` to include all five new tools.

Create/update categories:

## On-Page SEO

- SERP Preview
- Meta Title Generator
- Meta Description Generator
- Slug Generator
- Meta Robots Generator

## Technical SEO

- Robots.txt Generator
- Canonical URL Generator
- Hreflang Generator
- Schema Markup Generator

## Social & Metadata

- Open Graph Generator

Keep existing tools.

Do not remove existing tools.

Make the categories visually clear.

---

# HOMEPAGE

If the homepage currently contains a "Popular SEO Tools" section, update it carefully to include the most useful tools.

Do not overcrowd the homepage.

Prioritize:

1. SERP Preview
2. Meta Title Generator
3. Meta Description Generator
4. Schema Markup Generator
5. Slug Generator
6. Canonical URL Generator

The remaining tools can be discovered through `/tools/`.

---

# DESIGN SYSTEM

All five tools must use the existing Rank With Ajay UI.

Do not create five different designs.

Use:

- Same header
- Same footer
- Same page container
- Same card style
- Same button style
- Same input style
- Same typography
- Same spacing
- Same colors
- Same responsive breakpoints

The interface should feel like one coherent SEO product.

---

# TOOL INTERACTION QUALITY

Every tool must support:

### Empty state

Tell the user what to enter.

### Valid state

Show the generated output.

### Error state

Explain the problem in plain language.

### Copy state

Change:

**Copy**

to:

**Copied ✓**

temporarily.

### Clear state

Reset the form cleanly.

---

# ACCESSIBILITY

For all five tools:

- Proper `<label>` elements
- Keyboard navigation
- Visible focus states
- Accessible buttons
- Accessible selects
- Accessible checkboxes
- Accessible dynamic output
- Good color contrast
- Do not rely only on color to communicate status

Use ARIA only where appropriate.

---

# SECURITY

Treat all user input as untrusted.

Escape/sanitize all generated HTML output.

Never execute user-entered HTML or JavaScript.

Do not inject arbitrary user input directly into the DOM as executable markup.

The generated HTML should be displayed safely as text/code.

---

# PERFORMANCE

All five tools should primarily run client-side.

Do not add external APIs.

Do not add unnecessary network requests.

Do not add large dependencies.

Keep the tools lightweight and fast.

---

# SEO PAGE STRUCTURE

Every tool page must have:

- Exactly one H1
- Logical H2/H3 hierarchy
- Unique title
- Unique meta description
- Canonical URL
- Breadcrumb
- Internal links
- Helpful original content
- FAQ section
- Appropriate structured data

Do not keyword stuff.

Do not create thin pages.

The tool itself should be above the fold or very close to it.

---

# BREADCRUMBS

Use:

Home → Tools → [Tool Name]

Example:

Home → Tools → Slug Generator

Make the breadcrumbs clickable.

---

# STRUCTURED DATA

Use the existing structured-data architecture.

Add appropriate:

- BreadcrumbList
- WebApplication where genuinely appropriate

Do not add misleading ratings, reviews, prices or other unsupported properties.

---

# FINAL CTA

Use a consistent CTA:

**Explore More SEO Tools**

Supporting copy:

**Try more practical SEO tools from Rank With Ajay.**

Button:

**Browse All Tools →**

Link:

`/tools/`

---

# FINAL QA

After implementation, test every tool.

## Slug Generator

- Special characters
- Multiple spaces
- Accented characters
- Unicode
- Empty input
- Manual editing
- Copy
- Clear

## Canonical Generator

- Valid URL
- Invalid URL
- Query parameters
- Trailing slash
- HTTPS
- Copy

## Hreflang Generator

- Add row
- Remove row
- Language codes
- Region codes
- Duplicate hreflang
- Duplicate URLs
- x-default
- Invalid URL
- Copy
- Download

## Open Graph Generator

- Empty fields
- Valid image
- Invalid image
- Preview
- Twitter/X options
- Generated HTML
- Copy

## Meta Robots Generator

- index/noindex
- follow/nofollow
- snippet controls
- generated directive
- explanation
- copy
- clear

Test all pages at:

- 375px
- 390px
- 412px
- 768px
- 1024px
- 1280px
- 1440px

Ensure:

- No horizontal scrolling
- No broken layouts
- No console errors
- No broken links
- No existing tools are broken

---

# MOST IMPORTANT

These are **five separate SEO tools**, not five cosmetic pages.

Each tool must actually work.

Do not use mock output.

Do not use fake API responses.

Do not add placeholder functionality.

Everything that can be calculated or generated locally should work directly in the browser.

Keep the implementation modular so additional SEO tools can be added later without duplicating the entire codebase.