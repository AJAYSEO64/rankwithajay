You are redesigning the UI/UX of my existing website:

**Website:** Rank With Ajay
**Domain:** https://rankwithajay.in/

I have an existing working SEO tools website with approximately 28 SEO tools.

IMPORTANT:

* DO NOT remove, disable, rewrite, or break any existing SEO tool functionality.
* DO NOT change tool logic unless absolutely necessary for a visual component.
* DO NOT change URLs/routes/slugs.
* DO NOT remove existing pages, content, metadata, schema, internal links, or SEO functionality.
* DO NOT replace the website with a generic SaaS template.
* DO NOT rebuild the entire application from scratch.
* This is primarily a **UI/UX and visual design improvement project**.
* Preserve the existing React/Vite architecture and components wherever practical.
* First inspect the existing codebase and understand its current design system, components, routes, tools, and layouts.
* Then improve the visual system consistently across the entire website.

The goal is to make Rank With Ajay look like a **premium, modern, trustworthy SEO tools platform created by an SEO professional**.

---

# 1. DESIGN DIRECTION

Create a visual identity that combines:

**Premium SEO SaaS + Personal Expert Brand + Practical Utility**

The website should feel:

* Professional
* Modern
* Clean
* Fast
* Trustworthy
* Technical but approachable
* Easy to use
* High quality
* Human-designed
* Conversion-focused

Avoid making it look like:

* A generic AI startup
* A cryptocurrency website
* A template marketplace
* An overly colorful marketing website
* An enterprise corporate website
* A dashboard where everything is hidden behind complicated navigation

The website should communicate:

> "These are practical SEO tools created by someone who actually works in SEO."

---

# 2. OVERALL VISUAL STYLE

Use a refined modern design system.

Prioritize:

* Strong typography
* Excellent spacing
* Clear hierarchy
* Subtle borders
* Soft shadows
* Large but controlled whitespace
* Clean cards
* Consistent rounded corners
* Excellent form controls
* Clear CTAs
* Subtle visual accents
* High readability

Do not overuse:

* Gradients
* Glassmorphism
* Huge shadows
* Excessive animations
* Floating blobs
* Decorative illustrations
* Excessive icons
* Neon colors

The design should remain professional even if all decorative elements are removed.

---

# 3. COLOR SYSTEM

Create a consistent global color system.

Use:

* Neutral/white backgrounds for primary content
* Very light neutral sections for visual separation
* Dark text with excellent contrast
* One strong primary brand/accent color
* One secondary accent color used sparingly
* Muted colors for secondary information
* Clear success/warning/error states

Do not use many unrelated colors.

Create CSS variables/design tokens for:

* Background
* Surface
* Surface elevated
* Primary
* Primary hover
* Text
* Muted text
* Border
* Success
* Warning
* Error

Ensure the color system works consistently across every page and every tool.

---

# 4. TYPOGRAPHY

Improve typography significantly.

Use a modern, highly readable sans-serif font system.

Create a clear hierarchy:

H1:

* Large
* Strong
* Professional
* Responsive

H2:

* Clear section headings
* Strong visual hierarchy

H3:

* Tool/card headings
* Moderate emphasis

Body:

* Comfortable reading size
* Excellent line height

Small text:

* Used for metadata, hints, labels, and secondary information

Do not use excessively large headings that consume most of the screen.

On mobile, reduce heading sizes intelligently.

---

# 5. HEADER / NAVIGATION

Redesign the header to feel premium.

Desktop:

Logo/brand on the left:

**Rank With Ajay**

Navigation:

* Tools
* SEO Guides
* About Ajay
* Blog

Primary CTA:

**Explore Tools**

Use:

* Clean spacing
* Subtle bottom border
* Sticky header if appropriate
* Strong hover states
* Clear active state

Do not make the header unnecessarily tall.

Mobile:

Create a polished mobile navigation.

Use:

* Compact header
* Menu button
* Proper touch targets
* Clean mobile menu
* Clear CTA

The mobile navigation must feel intentionally designed, not like a desktop menu squeezed onto mobile.

---

# 6. HOMEPAGE HERO

Redesign the homepage hero to immediately communicate the website's purpose.

Primary message should clearly communicate:

**Free SEO Tools to Help You Rank Better**

Supporting message should explain that Rank With Ajay provides practical SEO tools for:

* SEO professionals
* Website owners
* Bloggers
* Marketers
* Businesses

Create a strong visual hierarchy:

1. Small brand/category label
2. Main headline
3. Supporting description
4. Primary CTA
5. Secondary CTA
6. Trust/supporting information

Primary CTA:

**Explore SEO Tools**

Secondary CTA:

**Learn SEO**

Do not make the hero overly complicated.

---

# 7. HERO VISUAL

Instead of generic illustrations, create a subtle visual representation of SEO tools.

For example:

A clean tool interface preview containing small cards such as:

* SERP Preview
* Meta Title
* Meta Description
* Schema
* Robots.txt

The visual should reinforce the product.

Do not use random stock images.

Do not use generic AI-generated people.

Do not use distracting illustrations.

---

# 8. TOOL DISCOVERY

The SEO tools are the core product.

Make tool discovery one of the strongest parts of the website.

Create a premium tools grid.

Each tool card should contain:

* Small icon
* Tool name
* Short one-line description
* Category
* Subtle arrow/action indicator

Example:

**SERP Preview Tool**
Preview how your title and description may appear in search results.

Card interaction:

* Slight border transition
* Subtle elevation
* Icon movement or arrow movement
* Clear hover state

Do not create excessive animation.

---

# 9. TOOL CATEGORIES

Make the 28 tools easy to discover.

Use clear categories such as:

* On-Page SEO
* Technical SEO
* Content SEO
* SERP & Metadata
* Schema & Structured Data
* URL & Indexing
* Social & Sharing
* Other SEO Utilities

Use category filters/tabs where appropriate.

Important:

The category navigation must not make the user feel like they are navigating a complicated dashboard.

Keep discovery simple.

---

# 10. TOOLS PAGE

Redesign `/tools/` as a premium SEO tool directory.

Top section:

H1:

**Free SEO Tools**

Supporting copy explaining what the tool collection does.

Then:

* Search tools
* Category filters
* Tool count
* Tool grid

Example:

**Search SEO tools...**

Users should be able to quickly type:

"meta"
"schema"
"robots"
"canonical"

and find relevant tools.

Add a clean "No results" state.

Do not add unnecessary filters.

---

# 11. TOOL PAGE DESIGN SYSTEM

Every individual tool should use the same visual structure.

Create a reusable ToolPage layout.

Structure:

### Breadcrumb

Home → Tools → Tool Name

### Tool Header

Tool name

Short explanation

### Main Tool Card

This is the most important element.

Use a large, clean card.

Inside:

* Inputs
* Labels
* Helpful descriptions
* Controls
* Generate/Preview button
* Results
* Copy button
* Reset button

### Result Area

Results should be visually separated from inputs.

Use:

* Light background
* Monospace font where appropriate
* Copy button
* Download button where applicable
* Success feedback after copying

### Educational Content

Below the tool:

* What this tool does
* How to use it
* SEO best practices
* Common mistakes
* FAQ

This maintains both UX and SEO value.

---

# 12. INPUT DESIGN

Improve all input fields.

Inputs should have:

* Clear labels
* Helpful placeholders
* Good height
* Comfortable padding
* Consistent border radius
* Strong focus state
* Error state
* Disabled state

Do not rely only on placeholder text.

Labels must remain visible.

Textareas should have sensible minimum heights.

Avoid overly dense forms.

---

# 13. BUTTON SYSTEM

Create a consistent button system.

Primary:

* Strong contrast
* Clear CTA
* Medium-large height

Secondary:

* Outlined or subtle background

Tertiary:

* Text/button style

Danger:

* Only when required

Every button should have:

* Hover state
* Active state
* Focus state
* Disabled state

Do not use oversized pill-shaped buttons everywhere.

Use rounded corners, but maintain a professional product aesthetic.

---

# 14. COPY / DOWNLOAD FEEDBACK

For tool outputs, improve micro-interactions.

When user clicks:

**Copy**

show:

**Copied**

temporarily.

For download:

show:

**Downloaded**

or another clear success state.

Avoid intrusive toast notifications.

Use subtle inline feedback where possible.

---

# 15. SERP PREVIEW TOOL

Give the SERP Preview tool a particularly polished interface because it is one of the flagship tools.

Structure:

Input panel on the left/top.

Preview panel on the right/underneath depending on screen width.

The Google-style preview should feel realistic but should not falsely claim to reproduce Google's exact rendering.

Make:

* Title
* URL
* Description

visually prominent.

Show character/pixel guidance clearly.

Metrics should be easy to understand.

Use visual status indicators:

* Good
* Getting long
* Likely to truncate

Keep the interface clean.

---

# 16. GENERATOR TOOLS

For generators such as:

* Meta Title Generator
* Meta Description Generator
* Slug Generator
* Canonical Generator
* Schema Generator
* Robots Generator
* Open Graph Generator
* Hreflang Generator

Use a consistent layout.

Recommended structure:

INPUT → GENERATE → RESULTS → COPY

The user should immediately understand:

"What do I enter?"

"What happens?"

"What do I copy?"

Do not make users search around the page for the generated result.

---

# 17. RESULT CARDS

Generated output should look like a useful deliverable.

Example:

┌─────────────────────────────┐
│ Generated Meta Description  │
│                             │
│ Your generated output...    │
│                             │
│                 Copy        │
└─────────────────────────────┘

Use clear visual separation between:

* Generated result
* Explanation
* Actions

For code/HTML/schema/robots output:

Use a proper monospace code container.

Add:

**Copy Code**

button.

---

# 18. ABOUT AJAY PAGE

Make `/about-ajay/` feel like a personal expert profile rather than a standard "About Us" page.

Position Ajay as:

**SEO & PPC Analyst**

Use a strong professional introduction.

Create sections for:

* About Ajay
* SEO experience
* Skills
* Tools/platforms
* Selected work
* Results
* Certifications
* Approach
* Why Rank With Ajay

Use timeline-style presentation for experience.

Use metric cards for achievements.

Example visual metrics:

**100+**
Keywords ranked #1

**25%+**
Average organic traffic lift

**33K+**
Organic clicks tracked

The numbers should be presented visually without overwhelming the page.

---

# 19. CASE STUDIES / RESULTS

Make project results visually compelling.

Use cards for selected projects.

Each card should include:

* Client/project
* Objective
* SEO work
* Result
* Key metric
* Relevant keyword/ranking information

Use a small "View case study" interaction if the corresponding page exists.

Do not fabricate case studies or statistics.

Only use existing verified website information.

---

# 20. SEO GUIDES / BLOG DESIGN

Improve the content section visually.

Blog cards should contain:

* Category
* Title
* Short description
* Reading time if available
* Date if available
* Arrow

Use consistent image treatment only if actual images exist.

Do not introduce stock images unnecessarily.

Create strong editorial hierarchy.

---

# 21. FAQ DESIGN

Use clean accordion components.

Each question should have:

* Clear question
* Plus/minus icon
* Smooth but subtle opening

Only one or a few sections should open depending on the existing functionality.

Do not use huge accordion cards.

---

# 22. FOOTER

Create a premium footer.

Sections:

**Rank With Ajay**

Short description.

**Tools**

* All SEO Tools
* Popular Tools
* Categories

**Resources**

* SEO Guides
* Blog
* About Ajay

**Legal**

* Privacy
* Terms

Include copyright.

Keep it clean and compact.

---

# 23. CARD DESIGN SYSTEM

Create one consistent card language.

Cards should use:

* Consistent radius
* Consistent border
* Consistent padding
* Very subtle shadow where useful
* Consistent hover behavior

Avoid making every section look like a different design system.

---

# 24. SPACING SYSTEM

Implement a consistent spacing scale.

Use predictable spacing for:

* Sections
* Cards
* Headings
* Paragraphs
* Forms
* Buttons
* Tool results

The website should breathe.

Avoid both:

* Excessive empty space
* Crowded interfaces

---

# 25. RESPONSIVE DESIGN

This is extremely important.

Design intentionally for:

### Desktop

1440px
1280px
1024px

### Tablet

768px

### Mobile

390px
375px
360px

Do not simply shrink desktop components.

For mobile:

* Stack tool inputs appropriately
* Make buttons full-width when useful
* Avoid horizontal overflow
* Keep code blocks horizontally scrollable if necessary
* Maintain readable typography
* Keep cards comfortable
* Ensure touch targets are at least approximately 44px
* Keep navigation usable

---

# 26. MOBILE-FIRST TOOL UX

On mobile, the user should be able to:

1. Enter information
2. Generate
3. See result
4. Copy result

without excessive scrolling.

Where possible, keep the primary action close to the input.

---

# 27. ICON SYSTEM

Use the existing icon library consistently.

Do not introduce random icon styles.

Icons should:

* Support meaning
* Remain subtle
* Have consistent stroke weight
* Use consistent sizing

Avoid using icons purely as decoration everywhere.

---

# 28. ANIMATIONS

Use minimal, premium animations.

Allowed:

* Button hover
* Card hover
* Accordion transition
* Subtle fade/slide
* Copy confirmation
* Page transitions if already supported

Avoid:

* Constant floating animations
* Excessive parallax
* Large moving gradients
* Distracting background animations
* Slow loading animations

Performance comes first.

---

# 29. ACCESSIBILITY

Improve accessibility throughout the design.

Ensure:

* Proper heading hierarchy
* Visible focus states
* Keyboard navigation
* Accessible labels
* Sufficient contrast
* Accessible buttons
* Accessible form errors
* Screen-reader-friendly interactive elements
* No information conveyed by color alone

Do not sacrifice accessibility for visual design.

---

# 30. SEO MUST REMAIN INTACT

This is a redesign, not an SEO migration.

Preserve:

* Existing URLs
* Existing page titles
* Meta descriptions
* Canonical tags
* Schema markup
* Breadcrumbs
* Internal links
* Heading structure where SEO-relevant
* Tool descriptions
* Existing content
* Robots directives
* Sitemap-related functionality
* Structured data

Do not change URL structures.

Do not create duplicate pages.

Do not remove SEO text simply to make pages visually shorter.

---

# 31. PERFORMANCE

The redesign must remain lightweight.

Avoid:

* Large unnecessary JavaScript libraries
* Heavy animation libraries
* Large image assets
* Video backgrounds
* Unnecessary external dependencies

Prefer:

* CSS
* Existing React components
* Existing icon library
* Optimized assets

The website should remain fast on mobile networks.

---

# 32. DESIGN TOKENS

Create or improve a centralized design system.

Define reusable variables/components for:

* Colors
* Typography
* Radius
* Shadows
* Borders
* Spacing
* Buttons
* Inputs
* Cards
* Badges
* Tool containers
* Alerts
* Code blocks

Do not individually style every page differently.

---

# 33. COMPONENT REUSABILITY

Create reusable components where appropriate:

* Header
* Footer
* Breadcrumbs
* ToolCard
* ToolGrid
* ToolPageLayout
* ToolHeader
* InputField
* Textarea
* PrimaryButton
* SecondaryButton
* ResultCard
* CopyButton
* CodeBlock
* FAQAccordion
* RelatedTools
* SectionHeader
* MetricCard

Use the existing components where possible instead of duplicating them.

---

# 34. RELATED TOOLS

At the bottom of each tool page, show relevant related tools.

Example:

Meta Title Generator:

* Meta Description Generator
* SERP Preview
* Open Graph Generator

Canonical URL Generator:

* Slug Generator
* Hreflang Generator
* Robots.txt Generator

This should look like a useful recommendation rather than advertising.

---

# 35. VISUAL HIERARCHY

Every page should answer these questions immediately:

1. Where am I?
2. What does this page/tool do?
3. What should I enter?
4. What should I click?
5. What result will I get?
6. What should I do next?

If the interface does not answer these questions clearly, improve it.

---

# 36. TRUST ELEMENTS

Add subtle trust signals where appropriate.

Examples:

* Free to use
* No signup required
* Browser-based tools
* No API required for applicable tools
* Built for practical SEO workflows

Do not make unsupported claims.

Do not create fake reviews or testimonials.

Do not create fake user counts.

Do not create fake logos.

---

# 37. EMPTY STATES

Design polished empty states.

For example:

Before generating:

**Your result will appear here**

with a short explanation.

Avoid showing a completely empty blank area.

---

# 38. ERROR STATES

Create clear error messages.

Instead of:

"Invalid input"

use:

**Please enter a valid URL**

Then explain what is expected.

Errors should be:

* Clear
* Short
* Actionable

---

# 39. DARK MODE

Do NOT automatically add dark mode unless the current application already supports it.

If dark mode already exists, improve it using the same design system.

Do not create two completely different visual identities.

---

# 40. FINAL VISUAL TARGET

The final website should feel comparable to a high-quality modern SEO software product while retaining the personality of an independent SEO professional.

Think:

**Ahrefs-style clarity**
+
**modern SaaS usability**
+
**personal SEO consultant credibility**
+
**simple independent-tool website**

But do NOT copy any company's design.

The final result should be distinctly:

**Rank With Ajay**

---

# 41. IMPORTANT IMPLEMENTATION RULE

Before making changes:

1. Inspect the complete existing project.
2. Identify all routes.
3. Identify all existing tools.
4. Identify reusable components.
5. Identify existing CSS/design tokens.
6. Identify existing responsive behavior.
7. Identify existing SEO components.
8. Identify existing tool functionality.

Then redesign the visual layer systematically.

Do not start by randomly modifying individual pages.

First establish the global design system.

Then apply it consistently.

---

# 42. QA CHECKLIST

After implementing the design:

### Desktop

* Header looks correct
* Homepage hero looks balanced
* Tool cards align correctly
* Forms are visually consistent
* Results are easy to understand
* Footer is polished

### Mobile

* No horizontal overflow
* Navigation works
* Tool forms work
* Buttons are usable
* Cards stack correctly
* Typography is readable
* Code outputs remain usable

### Functionality

Test every existing tool.

Ensure:

* Inputs work
* Generate buttons work
* Copy buttons work
* Download buttons work
* Validation works
* Existing outputs remain correct

### SEO

Verify:

* URLs unchanged
* Titles unchanged unless intentionally improved
* Meta descriptions preserved
* Canonicals preserved
* Schema preserved
* Breadcrumbs preserved
* Internal links preserved

### Performance

Avoid unnecessary dependencies and assets.

---

# 43. MOST IMPORTANT DESIGN PRINCIPLE

Do not redesign the website just to make it "beautiful."

Redesign it to make it:

**easier to understand → easier to navigate → easier to use → more trustworthy → more likely to return.**

The SEO tools are the product.

The design should make those tools feel extremely easy and valuable to use.

Before finishing, review the entire website as a first-time visitor and remove anything that creates unnecessary friction, visual noise, or confusion.
