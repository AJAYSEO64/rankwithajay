from pathlib import Path
from html import escape,unescape
import re,json
R=Path(__file__).resolve().parents[1];hub=(R/'tools/index.html').read_text()
groups={
'SERP & Metadata':['serp-preview','meta-title-generator','meta-description-generator','meta-tag-analyzer'],
'On-Page SEO':['seo-score-checker','heading-checker','image-alt-checker','internal-link-checker','website-seo-audit'],
'Technical SEO':['redirect-checker','broken-link-checker','http-status-checker','xml-sitemap-generator'],
'URLs & Indexing':['slug-generator','canonical-url-generator','canonical-checker','hreflang-generator','robots-txt-generator','meta-robots-generator'],
'Content SEO':['keyword-density-checker','search-intent-classifier','keyword-clustering','seo-content-brief','long-tail-keyword-generator'],
'Schema & Structured Data':['schema-generator','schema-validator'],
'Social & Sharing':['open-graph-generator','open-graph-preview']}
icons=['SERP','H1','HTTP','URL','Aa','{ }','OG'];items=[];cards={}
for card in re.findall(r'<a class="tool-card".*?</a>',hub,re.S):
 slug=re.search(r'href="/tools/([^/]+)/',card)[1];cat=next(k for k,v in groups.items() if slug in v)
 name=unescape(re.search(r'<h3>(.*?)</h3>',card)[1]);desc=unescape(re.search(r'<p>(.*?)</p>',card)[1]);mode=unescape(re.search(r'<span class="tool-mode">(.*?)</span>',card)[1])
 aliases='metadata facebook linkedin twitter social tags' if 'open-graph' in slug else 'robots indexing directives' if slug=='meta-robots-generator' else ''
 search=(name+' '+cat+' '+desc+' '+aliases).lower()
 item=dict(slug=slug,name=name,description=desc,category=cat,mode=mode,search=search,icon=icons[list(groups).index(cat)])
 items.append(item)
 cards[slug]=f'<a class="tool-card" href="/tools/{slug}/" data-name="{escape(search)}" data-category="{escape(cat)}"><div class="tool-card-top"><span class="icon" aria-hidden="true">{escape(item["icon"])}</span><span class="tool-mode">{escape(mode)}</span></div><h3>{escape(name)}</h3><p>{escape(desc)}</p><div class="tool-card-bottom"><span class="tool-category">{escape(cat)}</span><span aria-hidden="true">↗</span></div><span class="sr-only">Open tool</span></a>'
assert len(items)==28
(R/'extension/catalog-v4.js').write_text('window.RWACatalog = '+json.dumps(items,ensure_ascii=False)+';\n')
# Preserve the original head, title, metadata and all SEO schema.
start=hub.index('<section class="tool-group">');end=hub.index('<section id="rwa-no-results"',start)
sections=''.join('<section class="tool-group"><div class="group-heading"><h2>'+escape(cat)+'</h2><span>'+str(len(slugs))+' tools</span></div><div class="cards">'+''.join(cards[s] for s in slugs)+'</div></section>' for cat,slugs in groups.items())
hub=hub[:start]+sections+hub[end:]
hub=re.sub(r'<select id="category">.*?</select>','<select id="category"><option>All categories</option>'+''.join('<option>'+escape(c)+'</option>' for c in groups)+'</select>',hub,flags=re.S)
hub=re.sub(r'<div class="category-shortcuts".*?</div>','<div class="category-shortcuts" aria-label="Filter tools by category">'+''.join(f'<button type="button" data-category-filter="{escape(c)}" aria-pressed="{str(i==0).lower()}">{escape("All tools" if i==0 else c)} <span>{28 if i==0 else len(groups[c])}</span></button>' for i,c in enumerate(['All categories',*groups]))+'</div>',hub,flags=re.S)
hub=hub.replace('<div class="breadcrumb"><a href="/">Home</a> / Tools</div>','')
hub=hub.replace('<main id="main">','<main id="main"><div class="breadcrumb"><a href="/">Home</a> / Tools</div>')
(R/'tools/index.html').write_text(hub)
# One shared presentation stylesheet rather than three successive downloads.
css='\n'.join((R/'extension'/f).read_text() for f in ['design-v2.css','premium-v3.css'])
(R/'extension/platform-v4.css').write_text(css+'\n'+(R/'extension/platform-extras.css').read_text())
for p in [R/'index.html',*(R/'tools').rglob('index.html')]:
 if p.parent.name=='core-web-vitals':continue
 s=p.read_text();s=re.sub(r'<(?:link|script)[^>]*(?:platform-v4|catalog-v4)[^>]*>(?:</script>)?','',s);s=re.sub(r'<link rel="stylesheet" href="/extension/(?:design-v2|premium-v3)\.css[^\"]*">','',s)
 s=s.replace('</head>','<link rel="stylesheet" href="/extension/platform-v4.css?v=20260915"><script defer src="/extension/catalog-v4.js?v=20260915"></script><script defer src="/extension/platform-v4.js?v=20260915"></script></head>')
 p.write_text(s)
print('28 tools in seven categories; aliases indexed; shared visual bundle applied.')
