/* Product discovery only. Existing tool algorithms and result handlers are unchanged. */
(() => {
 'use strict';
 const tools=window.RWACatalog||[];
 const bySlug=new Map(tools.map(t=>[t.slug,t]));
 const categories=[...new Set(tools.map(t=>t.category))];
 const matches=(t,q,category='All tools')=>(category==='All tools'||t.category===category)&&q.trim().toLowerCase().split(/\s+/).every(word=>t.search.includes(word));
 const el=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text)n.textContent=text;return n};
 function card(t){const a=el('a','tool-card');a.href='/tools/'+t.slug+'/';const top=el('div','tool-card-top'),icon=el('span','icon',t.icon);icon.setAttribute('aria-hidden','true');top.append(icon,el('span','tool-mode',t.mode));const bottom=el('div','tool-card-bottom');bottom.append(el('span','tool-category',t.category));const arrow=el('span','','↗');arrow.setAttribute('aria-hidden','true');bottom.append(arrow);a.append(top,el('h3','',t.name),el('p','',t.description),bottom);return a}
 function directory(){
  const section=el('section','rwa-catalog-section');section.id='all-seo-tools';section.setAttribute('aria-labelledby','all-seo-tools-heading');
  const heading=el('div','rwa-section-heading'),intro=el('div');const h=el('h2','','Explore All SEO Tools');h.id='all-seo-tools-heading';intro.append(h,el('p','','Find the right tool for your next SEO task.'));heading.append(intro);const link=el('a','','Open tools directory →');link.href='/tools/';heading.append(link);
  const controls=el('div','rwa-directory-controls');const label=el('label','','Search SEO tools');label.htmlFor='home-tool-search';const input=el('input');input.id='home-tool-search';input.type='search';input.placeholder='Try meta, schema, robots or canonical';label.append(input);const catLabel=el('label','','Category');catLabel.htmlFor='home-tool-category';const select=el('select');select.id='home-tool-category';for(const c of ['All tools',...categories]){const option=el('option','',c);option.value=c;select.append(option)}catLabel.append(select);controls.append(label,catLabel);
  const count=el('p','rwa-directory-count');count.setAttribute('role','status');const grid=el('div','rwa-catalog-grid');const nodes=tools.map(t=>({t,a:card(t)}));nodes.forEach(({a})=>grid.append(a));
  const empty=el('div','rwa-directory-empty');empty.hidden=true;const clear=el('button','','Clear filters');clear.type='button';empty.append(el('h3','','No tools found'),el('p','','Try a different keyword or clear the selected category.'),clear);
  function update(){let n=0;for(const {t,a} of nodes){a.hidden=!matches(t,input.value,select.value);if(!a.hidden)n++}count.textContent=n+' of 28 tools';empty.hidden=n!==0}
  input.addEventListener('input',update);select.addEventListener('change',update);clear.addEventListener('click',()=>{input.value='';select.value='All tools';update();input.focus()});input.addEventListener('keydown',e=>{if(e.key==='Escape'){input.value='';update()}});
  section.append(heading,controls,count,grid,empty);update();return {section,input,update};
 }
 function heroSearch(target,dir){
  const form=el('form','rwa-hero-search');form.setAttribute('role','search');form.setAttribute('aria-label','Find an SEO tool');const label=el('label','','What SEO tool do you need?');label.htmlFor='hero-tool-search';const row=el('div','rwa-hero-search-row');const input=el('input');input.type='search';input.id='hero-tool-search';input.placeholder='Search SEO tools…';input.autocomplete='off';const button=el('button','','Find tool');button.type='submit';row.append(input,button);const results=el('div','rwa-hero-matches');results.id='hero-tool-matches';input.setAttribute('aria-controls',results.id);const status=el('span','sr-only');status.setAttribute('role','status');
  input.addEventListener('input',()=>{results.replaceChildren();const q=input.value.trim();if(!q){status.textContent='';return}const found=tools.filter(t=>matches(t,q));status.textContent=found.length+' matching tools';for(const t of found.slice(0,4)){const a=el('a','',t.name);a.href='/tools/'+t.slug+'/';a.append(el('span','','↗'));results.append(a)}if(!found.length)results.append(el('p','','No tools found. Try meta, schema or URL.'))});
  input.addEventListener('keydown',e=>{if(e.key==='Escape'){input.value='';results.replaceChildren();status.textContent=''}if(e.key==='ArrowDown'){const a=results.querySelector('a');if(a){e.preventDefault();a.focus()}}});
  form.addEventListener('submit',e=>{e.preventDefault();dir.input.value=input.value;dir.update();dir.section.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});dir.input.focus({preventScroll:true})});form.append(label,row,results,status);target.append(form);
 }
 const root=document.getElementById('root');
 if(root){
  let pending=false;
  function enhance(){
   if(location.pathname!=='/')return;const main=root.querySelector('main');if(!main)return;const hero=main.querySelector('h1')?.closest('section');if(!hero)return;
   if(!main.querySelector('#all-seo-tools')){const dir=directory();const anchor=main.querySelector('#categories');if(anchor)anchor.before(dir.section);else hero.after(dir.section);const column=hero.querySelector('h1').parentElement;heroSearch(column,dir);const strip=el('div','rwa-values');strip.setAttribute('aria-label','Toolkit features');for(const [strong,rest] of [['28',' SEO tools'],['Free',' to use'],['No signup',' required'],['Practical',' SEO workflows']]){const item=el('span');item.append(el('strong','',strong),document.createTextNode(rest));strip.append(item)}hero.after(strip)}
   const featured=main.querySelector('.rwa-popular-grid');if(featured&&!featured.dataset.platform){featured.dataset.platform='true';const order=['serp-preview','meta-title-generator','meta-description-generator','schema-generator','slug-generator','canonical-url-generator'];featured.replaceChildren(...order.map(s=>card(bySlug.get(s))))}
  }
  new MutationObserver(()=>{if(!pending){pending=true;requestAnimationFrame(()=>{pending=false;enhance()})}}).observe(root,{childList:true,subtree:true});enhance();
 }
 // The server-rendered directory keeps its existing search and category logic.
 // Apply a query from a bookmarked search without introducing a new route.
 if(document.body.dataset.tool==='hub'){const q=new URLSearchParams(location.search).get('q');if(q){const input=document.getElementById('search');input.value=q;input.dispatchEvent(new Event('input',{bubbles:true}))}}
})();
