from pathlib import Path
import re,html,json
R=Path(__file__).resolve().parents[1]
icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M4 17l6-6 4 4 6-9M14 6h6v6"/></svg>'
header=f'<header class="rwa-header"><div class="rwa-header-inner"><a class="rwa-brand" href="/">{icon}<span>Rank With Ajay</span></a><button type="button" class="rwa-menu-toggle" aria-expanded="false" aria-controls="rwa-main-nav">Menu</button><nav class="rwa-nav" id="rwa-main-nav" aria-label="Main navigation"><a href="/tools/" aria-current="page">Tools</a><a href="/#guides">SEO Guides</a><a href="/about-ajay/">About Ajay</a><a href="/blog/">Blog</a><a class="rwa-nav-cta" href="/tools/">Explore Tools</a></nav></div></header>'
footer=f'<footer class="rwa-footer"><div class="rwa-footer-inner"><div class="rwa-footer-grid"><div><a class="rwa-brand" href="/">{icon}<strong>Rank With Ajay</strong></a><p>Practical SEO tools and resources for better websites.</p></div><div><h3>Tools</h3><a href="/tools/">All SEO Tools</a><a href="/#tools">Popular Tools</a><a href="/#categories">Categories</a><a href="/tools/website-seo-audit/">Audit a page</a></div><div><h3>Resources</h3><a href="/#guides">SEO Guides</a><a href="/blog/">Blog</a><a href="/about-ajay/">About Ajay</a><a href="/contact/">Contact</a><a href="/">Home</a></div><div><h3>Legal</h3><a href="/privacy/">Privacy Policy</a><a href="/terms/">Terms of Service</a></div></div><div class="rwa-footer-bottom">© 2026 Rank With Ajay. All rights reserved.</div></div></footer>'
metadata={}
for p in [R/'index.html',*(R/'tools').rglob('index.html')]:
 if p.parent.name=='core-web-vitals':continue
 s=p.read_text()
 if 'premium-v3.css' in s:continue
 metadata[str(p.relative_to(R))]=re.findall(r'<title>.*?</title>|<meta\b[^>]*>|<link rel="canonical"[^>]*>|<script type="application/ld\+json">.*?</script>',s,re.S)
 s=s.replace('</head>','<link rel="stylesheet" href="/extension/premium-v3.css?v=20260911-3"><script defer src="/extension/premium-v3.js?v=20260911-3"></script></head>')
 if p!=R/'index.html':
  s=re.sub(r'<header\b.*?</header>',lambda m:header,s,count=1,flags=re.S)
  s=re.sub(r'<footer\b.*?</footer>',lambda m:footer,s,count=1,flags=re.S)
  if 'data-tool="hub"' in s:
   s=re.sub(r'<h1>.*?</h1>','<h1>Free SEO Tools</h1>',s,count=1,flags=re.S)
   s=s.replace('placeholder="Try “sitemap”, “keywords” or “meta”…"','placeholder="Search SEO tools…"')
   s=s.replace('</main>','<section id="rwa-no-results" class="rwa-no-results" hidden><h2>No tools found</h2><p>Try “meta”, “schema”, “robots” or “canonical”, or clear your filters.</p><button id="rwa-clear-filters" type="button">Clear filters</button></section></main>')
  def card(m):
   c=m[0];cat=re.search(r'data-category="([^"]+)"',c)
   if cat:c=c.replace('<h3>',f'<span class="tool-category">{cat[1]}</span><h3>',1)
   # Small consistent line icon; the heading supplies the specific tool identity.
   c=re.sub(r'<span class="icon">.*?</span>',lambda m:'<span class="icon">'+icon+'</span>',c,count=1)
   return c
  s=re.sub(r'<a class="tool-card".*?</a>',card,s,flags=re.S)
 p.write_text(s)


print('Applied shared navigation, footer, card categories, empty state and premium styles to all active pages.')
