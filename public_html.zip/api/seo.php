<?php
declare(strict_types=1);
/* PHP 8.1+, cURL and DOM. Enable in extension/config-v1.js after checking hosting support. */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
function fail(string $message, int $status=400): never { http_response_code($status); echo json_encode(['error'=>$message], JSON_INVALID_UTF8_SUBSTITUTE); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('Use POST to request a bounded page analysis.',405);
if (!extension_loaded('curl') || !extension_loaded('dom')) fail('The host must enable the PHP cURL and DOM extensions.',503);
if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0)>8192) fail('Request too large.',413);
if (!str_starts_with(strtolower($_SERVER['CONTENT_TYPE'] ?? ''),'application/json')) fail('Use application/json.',415);
$origin=$_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin !== '' && strtolower((string)parse_url($origin,PHP_URL_HOST))!==strtolower(explode(':',$_SERVER['HTTP_HOST'] ?? '')[0])) fail('Cross-origin requests are not allowed.',403);
// Atomic per-IP rate limit: at most 8 analyses/minute. Never trust forwarded IP headers.
$dir=sys_get_temp_dir().'/rwa-seo-limits';
if (!is_dir($dir) && !@mkdir($dir,0700,true) && !is_dir($dir)) fail('Rate limiter unavailable.',503);
$key=hash('sha256',$_SERVER['REMOTE_ADDR'] ?? 'unknown');
$file=@fopen($dir.'/'.$key,'c+');
if (!$file || !flock($file,LOCK_EX)) fail('Rate limiter unavailable.',503);
$state=json_decode(stream_get_contents($file) ?: '{}',true) ?: [];
$now=time(); if (($state['start'] ?? 0)+60<=$now) $state=['start'=>$now,'count'=>0];
if (($state['count'] ?? 0)>=8) { flock($file,LOCK_UN); fclose($file);header('Retry-After: 60');fail('Too many requests. Try again in one minute.',429); }
$state['count']=($state['count'] ?? 0)+1;ftruncate($file,0);rewind($file);fwrite($file,json_encode($state));flock($file,LOCK_UN);fclose($file);
// Opportunistic bounded cleanup to avoid unbounded temporary files.
if (random_int(1,100)===1) { $n=0; foreach(new DirectoryIterator($dir) as $entry){if(++$n>500)break;if($entry->isFile() && $entry->getMTime()<$now-3600)@unlink($entry->getPathname());} }
$raw=file_get_contents('php://input',false,null,0,8193);
if(strlen($raw)>8192)fail('Request too large.',413);
try{$in=json_decode($raw,true,16,JSON_THROW_ON_ERROR);}catch(Throwable $e){fail('Invalid JSON request.');}
if(!is_array($in)||!is_string($in['url']??null)||!is_string($in['operation']??null))fail('Provide a URL and an operation.');
$operation=$in['operation'];if(!in_array($operation,['page','status','redirects','links'],true))fail('Unsupported operation.');
$deadline=microtime(true)+16;
function publicIp(string $ip): bool {
 if(!filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE))return false;
 if(str_contains($ip,':')){
   // Accept only global unicast IPv6 2000::/3; reject transition, documentation and special ranges.
   $packed=inet_pton($ip);if(!$packed || (ord($packed[0]) & 0xe0)!==0x20)return false;
   $parts=unpack('n8',$packed);$first=$parts[1];$second=$parts[2];
   if($first===0x2001 && $second<0x0200)return false;
   if($first===0x2001 && $second===0x0db8)return false;
   if($first===0x2002)return false;
   if($first===0x3fff && $second<0x1000)return false;
   return true;
 }
 $n=ip2long($ip);foreach([['0.0.0.0',8],['100.64.0.0',10],['192.0.0.0',24],['192.0.2.0',24],['192.88.99.0',24],['198.18.0.0',15],['198.51.100.0',24],['203.0.113.0',24],['224.0.0.0',4],['240.0.0.0',4]] as [$base,$bits]){ $mask=-1 << (32-$bits);if(($n & $mask)===(ip2long($base)&$mask))return false; }return true;
}
function checkedUrl(string $url): array {
 if(strlen($url)>2048||preg_match('/[\x00-\x20\x7f\\\\]/',$url))throw new RuntimeException('Invalid URL characters.');
 $p=parse_url($url);if(!$p||!in_array(strtolower($p['scheme']??''),['http','https'],true)||empty($p['host'])||isset($p['user'])||isset($p['pass']))throw new RuntimeException('Use a public HTTP or HTTPS URL without credentials.');
 $host=strtolower(trim($p['host'],'[]'));$scheme=strtolower($p['scheme']);$port=$p['port']??($scheme==='https'?443:80);
 if($port!==($scheme==='https'?443:80))throw new RuntimeException('Only standard HTTP/HTTPS ports are allowed.');
 if(filter_var($host,FILTER_VALIDATE_IP))$ips=[$host];else{
  if(!preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/D',$host))throw new RuntimeException('Use a public DNS hostname.');
  $records=@dns_get_record($host,DNS_A|DNS_AAAA);$ips=[];foreach($records?:[] as $r){if(isset($r['ip']))$ips[]=$r['ip'];if(isset($r['ipv6']))$ips[]=$r['ipv6'];}
 }
 if(!$ips)throw new RuntimeException('The hostname could not be resolved.');foreach($ips as $ip)if(!publicIp($ip))throw new RuntimeException('Private, reserved and mixed public/private destinations are blocked.');
 return [$host,$port,$ips[0]];
}
function absoluteUrl(string $ref,string $base): string {
 $ref=trim($ref);if(preg_match('/^[a-z][a-z0-9+.-]*:/i',$ref))return $ref;
 $b=parse_url($base);$origin=$b['scheme'].'://'.$b['host'].(isset($b['port'])?':'.$b['port']:'');
 if(str_starts_with($ref,'//'))return $b['scheme'].':'.$ref;
 if($ref===''||$ref[0]==='#')return preg_replace('/#.*$/','',$base).$ref;
 if($ref[0]==='?')return $origin.($b['path']??'/').$ref;
 $path=$ref[0]==='/'?$ref:preg_replace('~/[^/]*$~','/',($b['path']??'/')).$ref;
 $parts=explode('/',explode('?',$path,2)[0]);$out=[];foreach($parts as $part){if($part==='..')array_pop($out);elseif($part!=='.')$out[]=$part;}
 return $origin.implode('/',$out).(str_contains($path,'?')?'?'.explode('?',$path,2)[1]:'');
}
function fetchPage(string $url,bool $head=false): array {
 global $deadline;$chain=[];$seen=[];$started=microtime(true);
 for($i=0;$i<6;$i++){
  if(microtime(true)>$deadline)throw new RuntimeException('Analysis time limit reached.');
  $url=preg_replace('/#.*$/','',$url);if(isset($seen[$url]))throw new RuntimeException('Redirect loop detected.');$seen[$url]=true;
  [$host,$port,$ip]=checkedUrl($url);$body='';$headers=[];$bytes=0;$tooBig=false;
  $curl=curl_init($url);$pin=str_contains($ip,':')?'['.$ip.']':$ip;
  curl_setopt_array($curl,[CURLOPT_FOLLOWLOCATION=>false,CURLOPT_PROTOCOLS=>CURLPROTO_HTTP|CURLPROTO_HTTPS,CURLOPT_REDIR_PROTOCOLS=>CURLPROTO_HTTP|CURLPROTO_HTTPS,CURLOPT_PROXY=>'',CURLOPT_RESOLVE=>[$host.':'.$port.':'.$pin],CURLOPT_CONNECTTIMEOUT=>3,CURLOPT_TIMEOUT_MS=>max(1,min(6000,(int)(($deadline-microtime(true))*1000))),CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_NOBODY=>$head,CURLOPT_USERAGENT=>'RankWithAjaySEOChecker/1.0 (+https://rankwithajay.in/tools/)',CURLOPT_HTTPHEADER=>['Accept: text/html,application/xhtml+xml;q=0.9,*/*;q=0.1'],CURLOPT_ENCODING=>'',CURLOPT_HEADERFUNCTION=>function($ch,$line)use(&$headers,&$bytes,&$tooBig){$bytes+=strlen($line);if($bytes>32768){$tooBig=true;return 0;}if(str_contains($line,':')){[$k,$v]=explode(':',$line,2);$headers[strtolower(trim($k))]=trim($v);}return strlen($line);},CURLOPT_WRITEFUNCTION=>function($ch,$chunk)use(&$body,&$tooBig){if(strlen($body)+strlen($chunk)>500000){$tooBig=true;return 0;}$body.=$chunk;return strlen($chunk);}]);
  $ok=curl_exec($curl);$code=(int)curl_getinfo($curl,CURLINFO_RESPONSE_CODE);$contentType=(string)curl_getinfo($curl,CURLINFO_CONTENT_TYPE);$error=curl_errno($curl);curl_close($curl);
  if($tooBig)throw new RuntimeException('Response exceeded the 500 KB body or 32 KB header limit.');
  if($ok===false)throw new RuntimeException($error===CURLE_OPERATION_TIMEDOUT?'The remote website timed out.':'The remote website could not be reached securely.');
  $location=$headers['location']??'';$chain[]=['url'=>$url,'status'=>$code,'location'=>$location?absoluteUrl($location,$url):null];
  if(in_array($code,[301,302,303,307,308],true)&&$location){$url=absoluteUrl($location,$url);continue;}
  return ['html'=>$body,'chain'=>$chain,'finalUrl'=>$url,'status'=>$code,'contentType'=>$contentType,'responseTimeMs'=>round((microtime(true)-$started)*1000)];
 }
 throw new RuntimeException('More than five redirects.');
}
try {
 checkedUrl($in['url']);
  $result=fetchPage($in['url'],in_array($operation,['status','redirects'],true));
  if($operation==='page'){
   if($result['status']<200||$result['status']>=300)throw new RuntimeException('The source page returned HTTP '.$result['status'].'.');
   if(!preg_match('~(?:text/html|application/xhtml\+xml)~i',$result['contentType']))throw new RuntimeException('The URL did not return an HTML page.');
  }elseif($operation==='links'){
   if($result['status']<200||$result['status']>=300)throw new RuntimeException('The source page returned HTTP '.$result['status'].'.');
   $doc=new DOMDocument();$prev=libxml_use_internal_errors(true);$doc->loadHTML($result['html'],LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);libxml_clear_errors();libxml_use_internal_errors($prev);
   $links=[];$seen=[];$limit=max(1,min(20,(int)($in['limit']??20)));$base=$result['finalUrl'];
   foreach($doc->getElementsByTagName('a') as $a){if(!$a->hasAttribute('href'))continue;$href=absoluteUrl($a->getAttribute('href'),$base);if(!preg_match('~^https?://~i',$href)||isset($seen[$href]))continue;$seen[$href]=true;
    if(count($links)>=$limit)break;$row=['url'=>$href,'anchor'=>trim($a->textContent),'type'=>parse_url($href,PHP_URL_HOST)===parse_url($base,PHP_URL_HOST)?'Internal':'External','status'=>null,'result'=>'Unable to check'];
    try{$check=fetchPage($href,true);$row['status']=$check['status'];$row['result']=in_array($check['status'],[401,403,429],true)?'Blocked':($check['status']>=400?'Broken':(count($check['chain'])>1?'Redirect':($check['status']>=200&&$check['status']<300?'Working':'Unable to check')));}catch(Throwable $e){$row['reason']=$e->getMessage();}
    $links[]=$row;
   }
   $result=['links'=>$links,'limit'=>$limit,'sourceUrl'=>$base];
  }else unset($result['html']);
 echo json_encode($result,JSON_INVALID_UTF8_SUBSTITUTE|JSON_UNESCAPED_SLASHES);
}catch(Throwable $e){fail($e->getMessage(),422);}
